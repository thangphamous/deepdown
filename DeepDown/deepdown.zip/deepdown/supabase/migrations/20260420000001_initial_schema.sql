-- deepdown initial schema
-- Run this in your Supabase SQL editor, or via `supabase db push`

-- ============================================================================
-- USERS & PROFILES
-- ============================================================================

-- Supabase's auth.users is managed by Supabase. We mirror a public.users row
-- via trigger so we can foreign-key cleanly from our own tables.

create table public.users (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null unique,
  display_name text,
  avatar_url text,
  auth_provider text,
  settings jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.users (id, email, display_name, avatar_url, auth_provider)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name', split_part(new.email, '@', 1)),
    new.raw_user_meta_data->>'avatar_url',
    new.raw_app_meta_data->>'provider'
  );
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ============================================================================
-- FRAMEWORKS
-- ============================================================================

create table public.frameworks (
  id text primary key, -- ikigai, nine, archetype, strengths, frequencies, love_language
  name text not null,
  description text,
  question_count int not null,
  estimated_minutes int not null,
  config jsonb not null default '{}'::jsonb,
  version int not null default 1,
  created_at timestamptz not null default now()
);

-- Seed the six frameworks
insert into public.frameworks (id, name, description, question_count, estimated_minutes) values
  ('ikigai', 'Ikigai', 'Your reason for being', 20, 5),
  ('nine', 'The Nine', 'Your core motivation', 27, 5),
  ('archetype', 'Archetype', 'Your cognitive style', 24, 5),
  ('strengths', 'Strengths', 'Your top talents', 30, 5),
  ('frequencies', 'Frequencies', 'How you transmit', 21, 5),
  ('love_language', 'Love Language', 'How you give and receive love', 20, 4);

-- ============================================================================
-- ASSESSMENTS & RESPONSES
-- ============================================================================

create table public.assessments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users(id) on delete cascade,
  framework_id text not null references public.frameworks(id),
  framework_version int not null default 1,
  status text not null default 'in_progress', -- in_progress, completed, abandoned
  result jsonb,
  started_at timestamptz not null default now(),
  completed_at timestamptz,
  updated_at timestamptz not null default now(),
  constraint valid_status check (status in ('in_progress', 'completed', 'abandoned'))
);

create index idx_assessments_user on public.assessments(user_id);
create index idx_assessments_user_framework on public.assessments(user_id, framework_id);

create table public.responses (
  id uuid primary key default gen_random_uuid(),
  assessment_id uuid not null references public.assessments(id) on delete cascade,
  question_id text not null,
  answer jsonb not null,
  answered_at timestamptz not null default now()
);

create index idx_responses_assessment on public.responses(assessment_id);
create unique index idx_responses_unique on public.responses(assessment_id, question_id);

-- ============================================================================
-- PROFILES & ARCHETYPES
-- ============================================================================

create table public.profiles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null unique references public.users(id) on delete cascade,
  archetype_name text,
  summary text,
  framework_results jsonb not null default '{}'::jsonb,
  completion_pct int not null default 0,
  last_synthesized_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index idx_profiles_user on public.profiles(user_id);

-- Create a profile row automatically when a user is created
create or replace function public.handle_new_profile()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (user_id) values (new.id);
  return new;
end;
$$;

create trigger on_user_created_make_profile
  after insert on public.users
  for each row execute function public.handle_new_profile();

create table public.archetypes (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null references public.profiles(id) on delete cascade,
  qualifier text not null,
  role text not null,
  narrative text,
  framework_snapshot jsonb not null, -- snapshot of framework results at time of synthesis
  version int not null default 1,
  created_at timestamptz not null default now()
);

create index idx_archetypes_profile on public.archetypes(profile_id);

-- ============================================================================
-- WORKSPACES (personal, couple, team, family)
-- ============================================================================

create table public.workspaces (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  type text not null default 'personal', -- personal, couple, team, family
  plan text not null default 'free', -- free, paid, team
  created_by uuid references public.users(id) on delete set null,
  created_at timestamptz not null default now(),
  constraint valid_type check (type in ('personal', 'couple', 'team', 'family'))
);

create table public.workspace_members (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  user_id uuid not null references public.users(id) on delete cascade,
  role text not null default 'member', -- owner, admin, member
  visibility_settings jsonb not null default '{}'::jsonb,
  joined_at timestamptz not null default now(),
  constraint valid_role check (role in ('owner', 'admin', 'member'))
);

create unique index idx_workspace_members_unique on public.workspace_members(workspace_id, user_id);
create index idx_workspace_members_user on public.workspace_members(user_id);

-- Every new user gets their own personal workspace
create or replace function public.handle_new_personal_workspace()
returns trigger
language plpgsql
security definer set search_path = public
as $$
declare
  ws_id uuid;
begin
  insert into public.workspaces (name, type, created_by)
  values (coalesce(new.display_name, 'My deepdown'), 'personal', new.id)
  returning id into ws_id;

  insert into public.workspace_members (workspace_id, user_id, role)
  values (ws_id, new.id, 'owner');

  return new;
end;
$$;

create trigger on_user_created_make_workspace
  after insert on public.users
  for each row execute function public.handle_new_personal_workspace();

-- ============================================================================
-- SHARES (send your deepdown to someone)
-- ============================================================================

create table public.shares (
  id uuid primary key default gen_random_uuid(),
  from_user_id uuid not null references public.users(id) on delete cascade,
  to_email text,
  to_user_id uuid references public.users(id) on delete set null,
  share_token text not null unique default encode(gen_random_bytes(16), 'hex'),
  permissions jsonb not null default '{"frameworks": "all", "narrative": true}'::jsonb,
  viewed_at timestamptz,
  expires_at timestamptz,
  created_at timestamptz not null default now()
);

create index idx_shares_from_user on public.shares(from_user_id);
create index idx_shares_token on public.shares(share_token);

-- ============================================================================
-- RELATIONSHIPS (couples / dating layer — v2)
-- ============================================================================

create table public.relationships (
  id uuid primary key default gen_random_uuid(),
  user_a_id uuid not null references public.users(id) on delete cascade,
  user_b_id uuid not null references public.users(id) on delete cascade,
  type text not null default 'friend', -- dating, partner, spouse, friend
  status text not null default 'pending', -- pending, active, ended
  initiated_by uuid not null references public.users(id) on delete cascade,
  compatibility_cache jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint valid_rel_type check (type in ('dating', 'partner', 'spouse', 'friend')),
  constraint valid_rel_status check (status in ('pending', 'active', 'ended')),
  constraint distinct_users check (user_a_id <> user_b_id)
);

create index idx_relationships_user_a on public.relationships(user_a_id);
create index idx_relationships_user_b on public.relationships(user_b_id);

-- ============================================================================
-- ROW LEVEL SECURITY
-- ============================================================================

alter table public.users enable row level security;
alter table public.profiles enable row level security;
alter table public.assessments enable row level security;
alter table public.responses enable row level security;
alter table public.archetypes enable row level security;
alter table public.workspaces enable row level security;
alter table public.workspace_members enable row level security;
alter table public.shares enable row level security;
alter table public.relationships enable row level security;
alter table public.frameworks enable row level security;

-- Frameworks are public-readable
create policy "frameworks are viewable by everyone"
  on public.frameworks for select using (true);

-- Users can read their own row, and update it
create policy "users can view self" on public.users
  for select using (auth.uid() = id);
create policy "users can update self" on public.users
  for update using (auth.uid() = id);

-- Profiles: own profile + profiles of people who shared with you (handled at app level)
create policy "profiles viewable by owner"
  on public.profiles for select using (auth.uid() = user_id);
create policy "profiles updatable by owner"
  on public.profiles for update using (auth.uid() = user_id);

-- Assessments: owned by user
create policy "assessments viewable by owner"
  on public.assessments for select using (auth.uid() = user_id);
create policy "assessments insertable by owner"
  on public.assessments for insert with check (auth.uid() = user_id);
create policy "assessments updatable by owner"
  on public.assessments for update using (auth.uid() = user_id);

-- Responses: viewable/writable if user owns the parent assessment
create policy "responses viewable by assessment owner"
  on public.responses for select using (
    exists (select 1 from public.assessments a where a.id = assessment_id and a.user_id = auth.uid())
  );
create policy "responses insertable by assessment owner"
  on public.responses for insert with check (
    exists (select 1 from public.assessments a where a.id = assessment_id and a.user_id = auth.uid())
  );

-- Archetypes: viewable by profile owner
create policy "archetypes viewable by owner"
  on public.archetypes for select using (
    exists (select 1 from public.profiles p where p.id = profile_id and p.user_id = auth.uid())
  );

-- Workspaces: viewable by members
create policy "workspaces viewable by members"
  on public.workspaces for select using (
    exists (select 1 from public.workspace_members wm where wm.workspace_id = id and wm.user_id = auth.uid())
  );

create policy "workspace_members viewable by self"
  on public.workspace_members for select using (user_id = auth.uid());

-- Shares: from_user can read their own; public read via token is handled at app layer with service role
create policy "shares viewable by sender"
  on public.shares for select using (from_user_id = auth.uid());
create policy "shares insertable by sender"
  on public.shares for insert with check (from_user_id = auth.uid());

-- Relationships
create policy "relationships viewable by participants"
  on public.relationships for select using (auth.uid() in (user_a_id, user_b_id));

-- ============================================================================
-- UPDATED_AT TRIGGERS
-- ============================================================================

create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger set_updated_at_users before update on public.users for each row execute function public.set_updated_at();
create trigger set_updated_at_profiles before update on public.profiles for each row execute function public.set_updated_at();
create trigger set_updated_at_assessments before update on public.assessments for each row execute function public.set_updated_at();
create trigger set_updated_at_relationships before update on public.relationships for each row execute function public.set_updated_at();
