export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[];

export type Database = {
  __InternalSupabase: {
    PostgrestVersion: '12';
  };
  public: {
    Tables: {
      users: {
        Row: {
          id: string;
          email: string;
          display_name: string | null;
          avatar_url: string | null;
          auth_provider: string | null;
          settings: Json;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          email: string;
          display_name?: string | null;
          avatar_url?: string | null;
          auth_provider?: string | null;
          settings?: Json;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          email?: string;
          display_name?: string | null;
          avatar_url?: string | null;
          auth_provider?: string | null;
          settings?: Json;
          created_at?: string;
          updated_at?: string;
        };
        Relationships: [];
      };
      frameworks: {
        Row: {
          id: string;
          name: string;
          description: string | null;
          question_count: number;
          estimated_minutes: number;
          config: Json;
          version: number;
          created_at: string;
        };
        Insert: {
          id: string;
          name: string;
          description?: string | null;
          question_count: number;
          estimated_minutes: number;
          config?: Json;
          version?: number;
          created_at?: string;
        };
        Update: {
          id?: string;
          name?: string;
          description?: string | null;
          question_count?: number;
          estimated_minutes?: number;
          config?: Json;
          version?: number;
          created_at?: string;
        };
        Relationships: [];
      };
      assessments: {
        Row: {
          id: string;
          user_id: string;
          framework_id: string;
          framework_version: number;
          status: 'in_progress' | 'completed' | 'abandoned';
          result: Json | null;
          started_at: string;
          completed_at: string | null;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          framework_id: string;
          framework_version?: number;
          status?: 'in_progress' | 'completed' | 'abandoned';
          result?: Json | null;
          started_at?: string;
          completed_at?: string | null;
          updated_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          framework_id?: string;
          framework_version?: number;
          status?: 'in_progress' | 'completed' | 'abandoned';
          result?: Json | null;
          started_at?: string;
          completed_at?: string | null;
          updated_at?: string;
        };
        Relationships: [];
      };
      responses: {
        Row: {
          id: string;
          assessment_id: string;
          question_id: string;
          answer: Json;
          answered_at: string;
        };
        Insert: {
          id?: string;
          assessment_id: string;
          question_id: string;
          answer: Json;
          answered_at?: string;
        };
        Update: {
          id?: string;
          assessment_id?: string;
          question_id?: string;
          answer?: Json;
          answered_at?: string;
        };
        Relationships: [];
      };
      profiles: {
        Row: {
          id: string;
          user_id: string;
          archetype_name: string | null;
          summary: string | null;
          framework_results: Json;
          completion_pct: number;
          last_synthesized_at: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          archetype_name?: string | null;
          summary?: string | null;
          framework_results?: Json;
          completion_pct?: number;
          last_synthesized_at?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          archetype_name?: string | null;
          summary?: string | null;
          framework_results?: Json;
          completion_pct?: number;
          last_synthesized_at?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Relationships: [];
      };
      archetypes: {
        Row: {
          id: string;
          profile_id: string;
          qualifier: string;
          role: string;
          narrative: string | null;
          framework_snapshot: Json;
          version: number;
          created_at: string;
        };
        Insert: {
          id?: string;
          profile_id: string;
          qualifier: string;
          role: string;
          narrative?: string | null;
          framework_snapshot: Json;
          version?: number;
          created_at?: string;
        };
        Update: {
          id?: string;
          profile_id?: string;
          qualifier?: string;
          role?: string;
          narrative?: string | null;
          framework_snapshot?: Json;
          version?: number;
          created_at?: string;
        };
        Relationships: [];
      };
      workspaces: {
        Row: {
          id: string;
          name: string;
          type: 'personal' | 'couple' | 'team' | 'family';
          plan: string;
          created_by: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          name: string;
          type?: 'personal' | 'couple' | 'team' | 'family';
          plan?: string;
          created_by?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          name?: string;
          type?: 'personal' | 'couple' | 'team' | 'family';
          plan?: string;
          created_by?: string | null;
          created_at?: string;
        };
        Relationships: [];
      };
      workspace_members: {
        Row: {
          id: string;
          workspace_id: string;
          user_id: string;
          role: 'owner' | 'admin' | 'member';
          visibility_settings: Json;
          joined_at: string;
        };
        Insert: {
          id?: string;
          workspace_id: string;
          user_id: string;
          role?: 'owner' | 'admin' | 'member';
          visibility_settings?: Json;
          joined_at?: string;
        };
        Update: {
          id?: string;
          workspace_id?: string;
          user_id?: string;
          role?: 'owner' | 'admin' | 'member';
          visibility_settings?: Json;
          joined_at?: string;
        };
        Relationships: [];
      };
      shares: {
        Row: {
          id: string;
          from_user_id: string;
          to_email: string | null;
          to_user_id: string | null;
          share_token: string;
          permissions: Json;
          viewed_at: string | null;
          expires_at: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          from_user_id: string;
          to_email?: string | null;
          to_user_id?: string | null;
          share_token?: string;
          permissions?: Json;
          viewed_at?: string | null;
          expires_at?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          from_user_id?: string;
          to_email?: string | null;
          to_user_id?: string | null;
          share_token?: string;
          permissions?: Json;
          viewed_at?: string | null;
          expires_at?: string | null;
          created_at?: string;
        };
        Relationships: [];
      };
      relationships: {
        Row: {
          id: string;
          user_a_id: string;
          user_b_id: string;
          type: 'dating' | 'partner' | 'spouse' | 'friend';
          status: 'pending' | 'active' | 'ended';
          initiated_by: string;
          compatibility_cache: Json | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_a_id: string;
          user_b_id: string;
          type?: 'dating' | 'partner' | 'spouse' | 'friend';
          status?: 'pending' | 'active' | 'ended';
          initiated_by: string;
          compatibility_cache?: Json | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          user_a_id?: string;
          user_b_id?: string;
          type?: 'dating' | 'partner' | 'spouse' | 'friend';
          status?: 'pending' | 'active' | 'ended';
          initiated_by?: string;
          compatibility_cache?: Json | null;
          created_at?: string;
          updated_at?: string;
        };
        Relationships: [];
      };
    };
    Views: { [_ in never]: never };
    Functions: { [_ in never]: never };
  };
};
