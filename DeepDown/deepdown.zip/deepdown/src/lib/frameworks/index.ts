import type { Framework, FrameworkId, FrameworkResult, Answer } from './types';
import { archetypeFramework, scoreArchetype } from './archetype';
import { nineFramework, scoreNine } from './nine';
import { ikigaiFramework, scoreIkigai } from './ikigai';
import { strengthsFramework, scoreStrengths } from './strengths';
import { frequenciesFramework, scoreFrequencies } from './frequencies';
import { loveLanguageFramework, scoreLoveLanguage } from './love_language';

export const FRAMEWORKS: Record<FrameworkId, Framework> = {
  archetype: archetypeFramework,
  nine: nineFramework,
  ikigai: ikigaiFramework,
  strengths: strengthsFramework,
  frequencies: frequenciesFramework,
  love_language: loveLanguageFramework,
};

export const FRAMEWORK_ORDER: FrameworkId[] = [
  'archetype',
  'nine',
  'ikigai',
  'strengths',
  'frequencies',
  'love_language',
];

export function getFramework(id: FrameworkId): Framework {
  return FRAMEWORKS[id];
}

export function scoreFramework(id: FrameworkId, responses: Record<string, Answer>): FrameworkResult {
  switch (id) {
    case 'archetype':
      return scoreArchetype(responses as any);
    case 'nine':
      return scoreNine(responses as any);
    case 'ikigai':
      return scoreIkigai(responses as any);
    case 'strengths':
      return scoreStrengths(responses as any);
    case 'frequencies':
      return scoreFrequencies(responses as any);
    case 'love_language':
      return scoreLoveLanguage(responses as any);
  }
}

export * from './types';
