import type { Framework, ScenarioQuestion, ScenarioAnswer, FrequenciesResult } from './types';

// 7 frequencies inspired by Erwin McManus's work, but reframed secularly:
// - Seer:     sees what is emerging; pattern recognition into the future
// - Maker:    brings things into being; turns vision into form
// - Guide:    helps others find their way; teaches, mentors, orients
// - Warrior:  fights for what matters; protects, confronts, stands ground
// - Healer:   tends wounds; restores wholeness where there is damage
// - Witness:  sits with truth; bears honest testimony, does not flinch
// - Builder:  establishes the structure that lasts; systems, institutions, foundations

// 21 questions = 3 scenarios × 7 response options each

interface FreqOption {
  text: string;
  frequency: string;
}

const SCENARIOS: Array<{ prompt: string; options: FreqOption[] }> = [
  {
    prompt: 'A friend comes to you sobbing after a hard breakup. Your instinct is to…',
    options: [
      { text: 'Tell them the harder truth they might not want to hear', frequency: 'witness' },
      { text: 'Help them see what this might be pointing them toward', frequency: 'seer' },
      { text: 'Sit with them in the weight of it, no fixing', frequency: 'healer' },
      { text: 'Help them plan the next right step', frequency: 'guide' },
      { text: 'Defend them fiercely and call out what was wrong', frequency: 'warrior' },
      { text: 'Create a small ritual or space that marks this turning point', frequency: 'maker' },
      { text: 'Help them rebuild the daily structure they will need', frequency: 'builder' },
    ],
  },
  {
    prompt: 'You join a new team and notice the culture is quietly broken. Your first move is to…',
    options: [
      { text: 'Design the systems and norms that would make it healthier', frequency: 'builder' },
      { text: 'Name the thing no one is saying, even if it is uncomfortable', frequency: 'witness' },
      { text: 'Coach people individually to work and lead differently', frequency: 'guide' },
      { text: 'Build what a better version of this team could look like', frequency: 'maker' },
      { text: 'Draw a line with the person whose behavior is poisoning the well', frequency: 'warrior' },
      { text: 'Repair the trust that has been damaged', frequency: 'healer' },
      { text: 'Map where it is heading if nothing changes', frequency: 'seer' },
    ],
  },
  {
    prompt: 'You are invited to speak to a room of people in a meaningful moment. You most want to…',
    options: [
      { text: 'Show them a future they had not yet dared to imagine', frequency: 'seer' },
      { text: 'Help them see where they are and what their next step is', frequency: 'guide' },
      { text: 'Move them to action on something that matters', frequency: 'warrior' },
      { text: 'Tell the truth plainly, even the parts that sting', frequency: 'witness' },
      { text: 'Create something beautiful they will remember', frequency: 'maker' },
      { text: 'Offer a balm for what they are carrying', frequency: 'healer' },
      { text: 'Give them a framework they can use tomorrow', frequency: 'builder' },
    ],
  },
];

const questions: ScenarioQuestion[] = SCENARIOS.map((s, idx) => ({
  id: `freq_scenario_${idx + 1}`,
  format: 'scenario',
  prompt: s.prompt,
  options: s.options,
}));

export const frequenciesFramework: Framework = {
  id: 'frequencies',
  name: 'Frequencies',
  tagline: 'How you transmit',
  description: 'The instinctive way you move people and influence the world. Seven frequencies — you carry one primary, and often a secondary resonance.',
  estimatedMinutes: 5,
  questions,
};

export function scoreFrequencies(responses: Record<string, ScenarioAnswer>): FrequenciesResult {
  const scores: Record<string, number> = {
    seer: 0, maker: 0, guide: 0, warrior: 0, healer: 0, witness: 0, builder: 0,
  };

  for (const q of questions) {
    const answer = responses[q.id];
    if (!answer) continue;
    const chosen = q.options[answer.value];
    if (chosen) {
      scores[chosen.frequency] = (scores[chosen.frequency] || 0) + 1;
    }
  }

  const sorted = Object.entries(scores).sort((a, b) => b[1] - a[1]);
  const primary = sorted[0][0];
  const secondary = sorted[1][0];

  const primarySummaries: Record<string, string> = {
    seer: 'The Seer — you see what is emerging before others can',
    maker: 'The Maker — you bring the invisible into form',
    guide: 'The Guide — you help others find their way',
    warrior: 'The Warrior — you stand and fight for what matters',
    healer: 'The Healer — you restore what has been broken',
    witness: 'The Witness — you tell the truth without flinching',
    builder: 'The Builder — you establish what lasts',
  };

  return {
    framework: 'frequencies',
    primary,
    secondary,
    scores,
    summary: primarySummaries[primary] ?? `Your primary frequency is ${primary}`,
  };
}
