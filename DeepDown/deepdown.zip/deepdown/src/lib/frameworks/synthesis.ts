import type {
  FrameworkResult,
  IkigaiResult,
  NineResult,
  ArchetypeResult,
  StrengthsResult,
  FrequenciesResult,
  LoveLanguageResult,
  Archetype,
} from './types';

/**
 * The synthesis engine — the heart of deepdown.
 *
 * Takes results from all 6 (or partial) frameworks and composes a unified
 * archetype: "The [Qualifier] [Role]" with a narrative.
 *
 * Qualifier = blend of Archetype I/E + The Nine motivation + primary Frequency
 * Role = blend of Strengths dominant + Ikigai dominant quadrant
 */

type PartialResults = {
  archetype?: ArchetypeResult;
  nine?: NineResult;
  ikigai?: IkigaiResult;
  strengths?: StrengthsResult;
  frequencies?: FrequenciesResult;
  love_language?: LoveLanguageResult;
};

// Qualifier lookup tables
// Priority: Frequency (strongest signal) > Nine (emotional tone) > Archetype (I/E modulation)

const FREQUENCY_QUALIFIERS: Record<string, string> = {
  seer: 'Visionary',
  maker: 'Creative',
  guide: 'Mentoring',
  warrior: 'Fierce',
  healer: 'Tender',
  witness: 'Truthful',
  builder: 'Quiet',
};

const NINE_QUALIFIERS: Record<number, string> = {
  1: 'Principled',
  2: 'Devoted',
  3: 'Driven',
  4: 'Soulful',
  5: 'Contemplative',
  6: 'Loyal',
  7: 'Radiant',
  8: 'Commanding',
  9: 'Steady',
};

// If archetype is introverted, often soften the qualifier; if extraverted, amplify
const INTROVERT_OVERRIDES: Record<string, string> = {
  'Fierce': 'Quiet-Fierce',
  'Commanding': 'Still-Commanding',
  'Radiant': 'Luminous',
};

// Role lookup tables
// Role = Strengths top theme + Ikigai quadrant blend

const STRENGTH_ROLES: Record<string, string> = {
  Strategic: 'Strategist',
  Analytical: 'Analyst',
  Learner: 'Seeker',
  Input: 'Gatherer',
  Intellection: 'Thinker',
  Context: 'Historian',
  Empathy: 'Empath',
  Connectedness: 'Weaver',
  Developer: 'Cultivator',
  Harmony: 'Mediator',
  Relator: 'Companion',
  Includer: 'Gatherer',
  Achiever: 'Builder',
  Responsibility: 'Keeper',
  Discipline: 'Steward',
  Focus: 'Arrow',
  Restorative: 'Mender',
  Arranger: 'Orchestrator',
  Command: 'Leader',
  Communication: 'Voice',
  Activator: 'Catalyst',
  Woo: 'Connector',
  Significance: 'Beacon',
  'Self-Assurance': 'Anchor',
};

const IKIGAI_ROLE_MODIFIERS: Record<IkigaiResult['quadrant'], string | null> = {
  mission: 'Maker',    // prefer the Maker/Mission feel when ikigai is mission-dominant
  vocation: 'Shepherd', // vocation = calling that sustains
  profession: null,     // professional, no change
  passion: 'Artist',   // passion overrides to Artist when strengths allow
};

export function composeArchetype(results: PartialResults): Archetype {
  const qualifier = deriveQualifier(results);
  const role = deriveRole(results);
  const full_name = `The ${qualifier} ${role}`;
  const tags = deriveTags(results);
  const narrative = generateNarrative(qualifier, role, results);

  return { qualifier, role, full_name, narrative, tags };
}

function deriveQualifier(r: PartialResults): string {
  let qualifier: string;

  if (r.frequencies) {
    qualifier = FREQUENCY_QUALIFIERS[r.frequencies.primary] || 'Quiet';
  } else if (r.nine) {
    qualifier = NINE_QUALIFIERS[r.nine.type] || 'Quiet';
  } else if (r.archetype) {
    qualifier = r.archetype.scores.EI < 0 ? 'Contemplative' : 'Expressive';
  } else {
    qualifier = 'Emerging';
  }

  // Blend with Nine for emotional tone if we have both
  if (r.frequencies && r.nine) {
    const nineTone = NINE_QUALIFIERS[r.nine.type];
    if (r.nine.type === 5 && r.frequencies.primary !== 'seer') {
      qualifier = `Contemplative`;
    } else if (r.nine.type === 4) {
      qualifier = 'Soulful';
    } else if (r.nine.type === 8 && r.frequencies.primary === 'warrior') {
      qualifier = 'Fierce';
    } else if (r.nine.type === 2 && r.frequencies.primary === 'healer') {
      qualifier = 'Tender';
    } else if (r.nine.type === 9) {
      qualifier = 'Steady';
    }
  }

  // Archetype I/E modulation
  if (r.archetype && r.archetype.scores.EI < -30) {
    qualifier = INTROVERT_OVERRIDES[qualifier] || qualifier;
  }

  return qualifier;
}

function deriveRole(r: PartialResults): string {
  let role: string;

  if (r.strengths && r.strengths.top5.length > 0) {
    role = STRENGTH_ROLES[r.strengths.top5[0]] || 'Seeker';
  } else if (r.frequencies) {
    const FREQ_TO_ROLE: Record<string, string> = {
      seer: 'Visionary',
      maker: 'Maker',
      guide: 'Guide',
      warrior: 'Warrior',
      healer: 'Healer',
      witness: 'Witness',
      builder: 'Builder',
    };
    role = FREQ_TO_ROLE[r.frequencies.primary] || 'Seeker';
  } else {
    role = 'Seeker';
  }

  // Ikigai can override the role when quadrant is dominant
  if (r.ikigai) {
    const scores = r.ikigai.scores;
    const total = scores.love + scores.skilled + scores.world_needs + scores.paid_for;
    if (total > 0) {
      const modifier = IKIGAI_ROLE_MODIFIERS[r.ikigai.quadrant];
      if (modifier && r.ikigai.quadrant === 'mission' && role === 'Builder') {
        role = modifier;
      }
      if (r.ikigai.quadrant === 'passion' && ['Thinker', 'Analyst'].includes(role)) {
        role = 'Artist';
      }
    }
  }

  return role;
}

function deriveTags(r: PartialResults): string[] {
  const tags: string[] = [];
  if (r.archetype) tags.push(r.archetype.type);
  if (r.nine) tags.push(`Type ${r.nine.type}w${r.nine.wing}`);
  if (r.strengths && r.strengths.top5[0]) tags.push(r.strengths.top5[0]);
  if (r.frequencies) {
    const FREQ_LABELS: Record<string, string> = {
      seer: 'The Seer',
      maker: 'The Maker',
      guide: 'The Guide',
      warrior: 'The Warrior',
      healer: 'The Healer',
      witness: 'The Witness',
      builder: 'The Builder',
    };
    tags.push(FREQ_LABELS[r.frequencies.primary] || r.frequencies.primary);
  }
  if (r.love_language) tags.push(`${r.love_language.give_top} → ${r.love_language.receive_top}`);
  return tags;
}

function generateNarrative(qualifier: string, role: string, r: PartialResults): string {
  // The free-tier 1-paragraph narrative
  const openers: Record<string, string> = {
    Contemplative: 'You move through the world with quiet conviction — watching patterns emerge, then building what you have seen.',
    Visionary: 'You see the shape of what is coming before others can name it, and you cannot look away from it.',
    Fierce: 'You do not flinch. When something needs to be said or defended, you are the one who does it.',
    Tender: 'You carry a particular sensitivity — to people, to wounds, to what is quietly breaking — and you tend to it.',
    Soulful: 'There is a depth in you that most people do not reach. You feel everything, and it makes your work richer.',
    Steady: 'You are the calm center, the unmoved presence that lets other people finally exhale.',
    Principled: 'You hold a line. Not out of rigidity, but because you know what matters and you refuse to betray it.',
    Devoted: 'You love through action. The people in your life are shaped by your care more than they realize.',
    Driven: 'You convert vision into outcomes. When you commit to something, it gets built.',
    Loyal: 'You stay. In a culture of exits, you keep showing up for the people and causes that are yours.',
    Radiant: 'You bring a lightness that opens rooms. Possibility gets easier to hold when you are in it.',
    Commanding: 'You take up the space a situation requires. When leadership is missing, you provide it.',
    Quiet: 'Your presence is felt more than announced. You make things that last.',
    Truthful: 'You tell the real thing. That is rarer than it sounds, and it is a gift.',
    Mentoring: 'You are drawn to help people find their way, and they feel it when you are in the room.',
    Creative: 'You bring things into form that did not exist before you. That is a kind of magic most people miss in themselves.',
  };

  const closers: Record<string, string> = {
    Builder: 'Most people miss what you notice. Most people rush past what you stay with.',
    Strategist: 'The clarity you bring is rare. Not everyone can see three moves ahead.',
    Weaver: 'You connect what others see as separate. That is its own kind of genius.',
    Healer: 'You hold what would crush other people, and it becomes something useful.',
    Guide: 'The people who get to be mentored by you do not forget it.',
    Warrior: 'When something matters, you do not go quiet. You become louder.',
    Visionary: 'You are not making up what you see. You are simply paying attention.',
    Witness: 'The world needs people willing to say what is actually happening. You are one of them.',
    Maker: 'What you create carries your fingerprints. It matters that it was you who made it.',
    Artist: 'Your work has a signature. It cannot be mistaken for anyone else.',
    Seeker: 'You are still becoming, and you know it. That is its own form of wisdom.',
    Empath: 'You feel what you are near. That is hard, and also why people tell you the truth.',
    Leader: 'You were built to take charge when others hesitate. Do not apologize for it.',
    Voice: 'What you say lands. Use it well.',
    Catalyst: 'Without you, things that needed to start would not have.',
    Mender: 'You find the broken thing and you sit with it until it works again.',
    Anchor: 'You do not drift. Other people steady themselves by you without realizing it.',
    Shepherd: 'You watch over what has been entrusted to you, and that is a form of love.',
    Historian: 'You know where we came from, and that is why you can see where to go.',
    Thinker: 'You do not accept easy answers. That is slow, until it is everything.',
    Orchestrator: 'You see all the moving pieces, and you find the pattern that works.',
    Cultivator: 'You believe in people before they believe in themselves, and you are usually right.',
    Mediator: 'You are the one who finds the middle path when everyone else has entrenched.',
    Beacon: 'People find their way by you. That is a responsibility, and a gift.',
    Keeper: 'What you promise gets done. What you guard stays safe.',
    Steward: 'You tend what has been given to you, carefully, and it grows.',
    Arrow: 'When you decide, you decide. Distraction does not catch you.',
    Companion: 'The people who are lucky enough to go deep with you know.',
    Gatherer: 'You collect what others will need before they know they need it.',
  };

  const opener = openers[qualifier] || `You are ${qualifier.toLowerCase()}, and it shapes everything.`;
  const closer = closers[role] || 'You are still discovering who you are. Keep going.';

  return `${opener} ${closer}`;
}

/**
 * Calculate how "complete" a profile is — simple percentage of frameworks done
 */
export function calculateCompletion(results: PartialResults): number {
  let done = 0;
  const total = 6;
  if (results.archetype) done++;
  if (results.nine) done++;
  if (results.ikigai) done++;
  if (results.strengths) done++;
  if (results.frequencies) done++;
  if (results.love_language) done++;
  return Math.round((done / total) * 100);
}
