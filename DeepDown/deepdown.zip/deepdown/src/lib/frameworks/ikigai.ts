import type { Framework, DualSliderQuestion, DualSliderAnswer, IkigaiResult } from './types';

// Ikigai has 4 axes:
// love ↔ indifferent
// skilled ↔ struggle
// world_needs ↔ world_ignores
// paid_for ↔ not_paid_for
//
// We use dual-sliders per activity for the two personal axes (love + skilled),
// then the other two axes are inferred from the activity tags + 2 open-text prompts
// (which we treat as optional qualitative signal). For v1 scoring we derive
// world_needs and paid_for from activity tags.

interface ActivityTag {
  id: string;
  activity: string;
  world_weight: number;  // 0-1, how much the world tends to need this
  paid_weight: number;   // 0-1, how commercially viable this typically is
}

const activities: ActivityTag[] = [
  { id: 'ik_1', activity: 'Teaching or mentoring others', world_weight: 0.9, paid_weight: 0.7 },
  { id: 'ik_2', activity: 'Making art, music, or creative writing', world_weight: 0.6, paid_weight: 0.4 },
  { id: 'ik_3', activity: 'Building physical things with your hands', world_weight: 0.8, paid_weight: 0.8 },
  { id: 'ik_4', activity: 'Writing software or solving technical problems', world_weight: 0.7, paid_weight: 0.95 },
  { id: 'ik_5', activity: 'Caring for people who are struggling', world_weight: 1.0, paid_weight: 0.6 },
  { id: 'ik_6', activity: 'Leading a team toward a shared goal', world_weight: 0.8, paid_weight: 0.9 },
  { id: 'ik_7', activity: 'Researching and deeply understanding a subject', world_weight: 0.7, paid_weight: 0.7 },
  { id: 'ik_8', activity: 'Selling or persuading people to change their minds', world_weight: 0.6, paid_weight: 0.9 },
  { id: 'ik_9', activity: 'Organizing chaos into working systems', world_weight: 0.8, paid_weight: 0.85 },
  { id: 'ik_10', activity: 'Performing in front of an audience', world_weight: 0.5, paid_weight: 0.5 },
  { id: 'ik_11', activity: 'Designing beautiful or useful objects', world_weight: 0.7, paid_weight: 0.75 },
  { id: 'ik_12', activity: 'Cooking or preparing food for others', world_weight: 0.7, paid_weight: 0.7 },
  { id: 'ik_13', activity: 'Physical movement, athletics, or training', world_weight: 0.6, paid_weight: 0.5 },
  { id: 'ik_14', activity: 'Listening deeply and helping people make sense of their lives', world_weight: 0.95, paid_weight: 0.7 },
  { id: 'ik_15', activity: 'Advocating for a cause or community', world_weight: 0.95, paid_weight: 0.4 },
  { id: 'ik_16', activity: 'Analyzing data and finding patterns', world_weight: 0.7, paid_weight: 0.9 },
  { id: 'ik_17', activity: 'Starting new ventures or projects from scratch', world_weight: 0.7, paid_weight: 0.85 },
  { id: 'ik_18', activity: 'Writing or speaking to large audiences', world_weight: 0.7, paid_weight: 0.7 },
  { id: 'ik_19', activity: 'Taking care of children or vulnerable people', world_weight: 1.0, paid_weight: 0.5 },
  { id: 'ik_20', activity: 'Facilitating conversations between difficult parties', world_weight: 0.9, paid_weight: 0.75 },
];

const questions: DualSliderQuestion[] = activities.map((a) => ({
  id: a.id,
  format: 'dual_slider',
  prompt: a.activity,
  axisA: { label: 'How much you love it', low: 'Indifferent', high: 'I love it' },
  axisB: { label: 'How skilled you are', low: 'Struggle', high: 'Highly skilled' },
}));

export const ikigaiFramework: Framework = {
  id: 'ikigai',
  name: 'Ikigai',
  tagline: 'Your reason for being',
  description: 'The intersection of what you love, what you are skilled at, what the world needs, and what you can be paid for — a map of your purpose.',
  estimatedMinutes: 5,
  questions,
};

export function scoreIkigai(responses: Record<string, DualSliderAnswer>): IkigaiResult {
  // Aggregate across all activities weighted by love and skill
  let totalLove = 0;
  let totalSkilled = 0;
  let totalWorld = 0;
  let totalPaid = 0;
  let count = 0;

  for (const activity of activities) {
    const answer = responses[activity.id];
    if (!answer) continue;
    // 0-100 sliders, normalize to 0-1
    const love = answer.axisA / 100;
    const skilled = answer.axisB / 100;
    // World-needs and paid-for signals are weighted by how much the user loves + is skilled at them
    const engagement = (love + skilled) / 2;
    totalLove += love;
    totalSkilled += skilled;
    totalWorld += activity.world_weight * engagement;
    totalPaid += activity.paid_weight * engagement;
    count += 1;
  }

  const n = Math.max(count, 1);
  const scores = {
    love: Math.round((totalLove / n) * 100),
    skilled: Math.round((totalSkilled / n) * 100),
    world_needs: Math.round((totalWorld / n) * 100),
    paid_for: Math.round((totalPaid / n) * 100),
  };

  // Determine dominant quadrant
  // Passion: love + skilled
  // Mission: love + world_needs
  // Vocation: world_needs + paid_for
  // Profession: skilled + paid_for
  const quadrants = {
    passion: (scores.love + scores.skilled) / 2,
    mission: (scores.love + scores.world_needs) / 2,
    vocation: (scores.world_needs + scores.paid_for) / 2,
    profession: (scores.skilled + scores.paid_for) / 2,
  };

  const dominant = Object.entries(quadrants).sort((a, b) => b[1] - a[1])[0][0] as IkigaiResult['quadrant'];

  const summaries: Record<IkigaiResult['quadrant'], string> = {
    passion: 'You thrive where love and skill meet — your work feels like play',
    mission: 'You thrive where meaning and love meet — your work serves something larger',
    vocation: 'You thrive where calling and livelihood meet — what you do matters and sustains you',
    profession: 'You thrive where skill and reward meet — you are built to produce',
  };

  return {
    framework: 'ikigai',
    quadrant: dominant,
    scores,
    summary: summaries[dominant],
  };
}
