import type { Framework, LikertQuestion, LikertAnswer, ArchetypeResult } from './types';

// 4 dimensions x 6 questions each = 24 questions
// EI: Extraversion vs Introversion
// SN: Sensing vs iNtuition
// TF: Thinking vs Feeling
// JP: Judging vs Perceiving

const questions: LikertQuestion[] = [
  // EI dimension (+1 = E, -1 = I)
  { id: 'arch_ei_1', format: 'likert', dimension: 'EI', polarity: 1, prompt: 'I feel energized after spending time in a group of people.' },
  { id: 'arch_ei_2', format: 'likert', dimension: 'EI', polarity: -1, prompt: 'I need meaningful alone time to feel like myself again.' },
  { id: 'arch_ei_3', format: 'likert', dimension: 'EI', polarity: 1, prompt: 'I often think out loud and figure out what I mean while speaking.' },
  { id: 'arch_ei_4', format: 'likert', dimension: 'EI', polarity: -1, prompt: 'I prefer to think things through privately before sharing.' },
  { id: 'arch_ei_5', format: 'likert', dimension: 'EI', polarity: 1, prompt: 'I tend to seek out new people and experiences.' },
  { id: 'arch_ei_6', format: 'likert', dimension: 'EI', polarity: -1, prompt: 'A quiet evening alone sounds more restorative than a party.' },

  // SN dimension (+1 = N, -1 = S)
  { id: 'arch_sn_1', format: 'likert', dimension: 'SN', polarity: 1, prompt: 'I often notice patterns and connections across different areas of life.' },
  { id: 'arch_sn_2', format: 'likert', dimension: 'SN', polarity: -1, prompt: 'I trust what I can directly observe more than theories about it.' },
  { id: 'arch_sn_3', format: 'likert', dimension: 'SN', polarity: 1, prompt: 'I get restless when conversations stay too close to surface facts.' },
  { id: 'arch_sn_4', format: 'likert', dimension: 'SN', polarity: -1, prompt: 'I am careful to ground ideas in specific, concrete examples.' },
  { id: 'arch_sn_5', format: 'likert', dimension: 'SN', polarity: 1, prompt: 'I find myself drawn to possibilities more than present realities.' },
  { id: 'arch_sn_6', format: 'likert', dimension: 'SN', polarity: -1, prompt: 'I trust step-by-step approaches more than intuitive leaps.' },

  // TF dimension (+1 = F, -1 = T)
  { id: 'arch_tf_1', format: 'likert', dimension: 'TF', polarity: 1, prompt: 'When making decisions, I weigh how they will affect the people involved.' },
  { id: 'arch_tf_2', format: 'likert', dimension: 'TF', polarity: -1, prompt: 'I try to keep emotion out of important analytical decisions.' },
  { id: 'arch_tf_3', format: 'likert', dimension: 'TF', polarity: 1, prompt: 'Harmony in my relationships affects my wellbeing a great deal.' },
  { id: 'arch_tf_4', format: 'likert', dimension: 'TF', polarity: -1, prompt: 'I can deliver hard truths without softening them much.' },
  { id: 'arch_tf_5', format: 'likert', dimension: 'TF', polarity: 1, prompt: 'I read the emotional undercurrent of a room almost automatically.' },
  { id: 'arch_tf_6', format: 'likert', dimension: 'TF', polarity: -1, prompt: 'I value logical consistency more than social tact.' },

  // JP dimension (+1 = J, -1 = P)
  { id: 'arch_jp_1', format: 'likert', dimension: 'JP', polarity: 1, prompt: 'I feel calmer when things are planned out in advance.' },
  { id: 'arch_jp_2', format: 'likert', dimension: 'JP', polarity: -1, prompt: 'I often change my plans when a more interesting option appears.' },
  { id: 'arch_jp_3', format: 'likert', dimension: 'JP', polarity: 1, prompt: 'I feel a small satisfaction each time I close out an item on my list.' },
  { id: 'arch_jp_4', format: 'likert', dimension: 'JP', polarity: -1, prompt: 'I prefer keeping my options open as long as possible.' },
  { id: 'arch_jp_5', format: 'likert', dimension: 'JP', polarity: 1, prompt: 'Unfinished things bother me until they are resolved.' },
  { id: 'arch_jp_6', format: 'likert', dimension: 'JP', polarity: -1, prompt: 'My best work often emerges in bursts rather than on a schedule.' },
];

export const archetypeFramework: Framework = {
  id: 'archetype',
  name: 'Archetype',
  tagline: 'Your cognitive style',
  description: 'How you take in the world and make decisions. Four dimensions, sixteen possible types — inspired by the classic temperament frameworks.',
  estimatedMinutes: 5,
  questions,
};

// Scoring
export function scoreArchetype(responses: Record<string, LikertAnswer>): ArchetypeResult {
  const dims: Record<string, { sum: number; count: number }> = {
    EI: { sum: 0, count: 0 },
    SN: { sum: 0, count: 0 },
    TF: { sum: 0, count: 0 },
    JP: { sum: 0, count: 0 },
  };

  for (const q of questions) {
    const answer = responses[q.id];
    if (!answer) continue;
    // Convert 1-5 likert to -2 to +2, apply polarity
    const centered = answer.value - 3;
    dims[q.dimension].sum += centered * q.polarity;
    dims[q.dimension].count += 1;
  }

  // Normalize each dimension to -100 to 100
  const scores = {
    EI: Math.round((dims.EI.sum / (dims.EI.count * 2)) * 100),
    SN: Math.round((dims.SN.sum / (dims.SN.count * 2)) * 100),
    TF: Math.round((dims.TF.sum / (dims.TF.count * 2)) * 100),
    JP: Math.round((dims.JP.sum / (dims.JP.count * 2)) * 100),
  };

  const type =
    (scores.EI >= 0 ? 'E' : 'I') +
    (scores.SN >= 0 ? 'N' : 'S') +
    (scores.TF >= 0 ? 'F' : 'T') +
    (scores.JP >= 0 ? 'J' : 'P');

  return {
    framework: 'archetype',
    type,
    scores,
    summary: archetypeSummaries[type] ?? `You are type ${type}.`,
  };
}

const archetypeSummaries: Record<string, string> = {
  INTJ: 'Strategic visionary, building systems from long-range patterns',
  INTP: 'Curious theorist, endlessly probing how things actually work',
  ENTJ: 'Decisive commander, mobilizing people and resources toward a vision',
  ENTP: 'Quick-witted provocateur, spinning possibilities faster than others can catch',
  INFJ: 'Quiet visionary, patterns over noise',
  INFP: 'Tender idealist, loyal to an inner truth most cannot see',
  ENFJ: 'Warm mobilizer, drawing out the best in everyone around you',
  ENFP: 'Luminous catalyst, igniting possibility wherever you go',
  ISTJ: 'Dependable guardian, quietly keeping what matters intact',
  ISFJ: 'Devoted caretaker, remembering what everyone else forgets',
  ESTJ: 'Practical executive, organizing chaos into working order',
  ESFJ: 'Generous host, weaving people into belonging',
  ISTP: 'Masterful tinkerer, understanding through the hands',
  ISFP: 'Gentle artist, expressing the ineffable through craft',
  ESTP: 'Present-tense athlete, alive in the immediate moment',
  ESFP: 'Joyful performer, bringing lightness into every room',
};
