import type { Framework, ForcedChoiceQuestion, ForcedChoiceAnswer, NineResult } from './types';

// 9 types, 3 questions per type paired against others = 27 questions
// Each question pits two types against each other; the chosen one gets +1

// Types:
// 1 - The Reformer (perfectionist, principled)
// 2 - The Helper (caring, interpersonal)
// 3 - The Achiever (success-oriented, adaptive)
// 4 - The Individualist (expressive, introspective)
// 5 - The Investigator (cerebral, perceptive)
// 6 - The Loyalist (committed, security-oriented)
// 7 - The Enthusiast (spontaneous, versatile)
// 8 - The Challenger (powerful, self-confident)
// 9 - The Peacemaker (easygoing, accommodating)

const questions: ForcedChoiceQuestion[] = [
  { id: 'nine_1v2', format: 'forced_choice', prompt: 'Which feels more like you?',
    options: [
      { text: 'I feel a quiet pressure to do things the right way, and it bothers me when I fall short.', type: '1' },
      { text: 'I notice what people need almost instinctively, and I feel fulfilled when I can give it.', type: '2' },
    ]},
  { id: 'nine_1v3', format: 'forced_choice', prompt: 'Which feels more like you?',
    options: [
      { text: 'I hold myself to a high moral standard and feel uneasy when I compromise.', type: '1' },
      { text: 'I shape myself to succeed at whatever I am trying to accomplish.', type: '3' },
    ]},
  { id: 'nine_1v6', format: 'forced_choice', prompt: 'Which feels more like you?',
    options: [
      { text: 'I feel most anxious when I know I am doing something wrong.', type: '1' },
      { text: 'I feel most anxious when I am not sure who or what to trust.', type: '6' },
    ]},

  { id: 'nine_2v9', format: 'forced_choice', prompt: 'Which feels more like you?',
    options: [
      { text: 'I want to be needed and loved by the people closest to me.', type: '2' },
      { text: 'I want peace and harmony, and I will minimize myself to keep it.', type: '9' },
    ]},
  { id: 'nine_2v4', format: 'forced_choice', prompt: 'Which feels more like you?',
    options: [
      { text: 'I often put others first and sometimes lose track of what I want.', type: '2' },
      { text: 'I often feel that something essential is missing from my life that others seem to have.', type: '4' },
    ]},
  { id: 'nine_2v3', format: 'forced_choice', prompt: 'Which feels more like you?',
    options: [
      { text: 'I want to matter to the people in my life.', type: '2' },
      { text: 'I want to be admired for what I achieve.', type: '3' },
    ]},

  { id: 'nine_3v7', format: 'forced_choice', prompt: 'Which feels more like you?',
    options: [
      { text: 'I measure a lot of my worth by what I accomplish.', type: '3' },
      { text: 'I chase new experiences and get bored when life feels contained.', type: '7' },
    ]},
  { id: 'nine_3v8', format: 'forced_choice', prompt: 'Which feels more like you?',
    options: [
      { text: 'I adapt to whatever the moment calls for and perform well.', type: '3' },
      { text: 'I move through the world with a lot of natural force and directness.', type: '8' },
    ]},
  { id: 'nine_3v1', format: 'forced_choice', prompt: 'Which feels more like you?',
    options: [
      { text: 'I want to win, and I will adjust my approach as needed to do so.', type: '3' },
      { text: 'I want to be right, and I will hold to a standard even when it costs me.', type: '1' },
    ]},

  { id: 'nine_4v5', format: 'forced_choice', prompt: 'Which feels more like you?',
    options: [
      { text: 'I feel like my inner emotional world is richer and stranger than most people realize.', type: '4' },
      { text: 'I retreat into ideas and feel most safe in my own mind.', type: '5' },
    ]},
  { id: 'nine_4v2', format: 'forced_choice', prompt: 'Which feels more like you?',
    options: [
      { text: 'I have a longing for something more meaningful that I cannot quite name.', type: '4' },
      { text: 'I have a pull toward being close to people and caring for them.', type: '2' },
    ]},
  { id: 'nine_4v9', format: 'forced_choice', prompt: 'Which feels more like you?',
    options: [
      { text: 'I feel most myself when I am being creatively authentic, even if it is difficult.', type: '4' },
      { text: 'I feel most myself when things are calm and everyone is getting along.', type: '9' },
    ]},

  { id: 'nine_5v6', format: 'forced_choice', prompt: 'Which feels more like you?',
    options: [
      { text: 'I want to understand things deeply before I commit energy to them.', type: '5' },
      { text: 'I want to know who I can trust before I commit energy to anything.', type: '6' },
    ]},
  { id: 'nine_5v7', format: 'forced_choice', prompt: 'Which feels more like you?',
    options: [
      { text: 'I am most energized by going deep into one thing.', type: '5' },
      { text: 'I am most energized by sampling many things.', type: '7' },
    ]},
  { id: 'nine_5v4', format: 'forced_choice', prompt: 'Which feels more like you?',
    options: [
      { text: 'My inner world is mostly thoughts, frameworks, and understanding.', type: '5' },
      { text: 'My inner world is mostly feelings, longings, and aesthetic sensitivity.', type: '4' },
    ]},

  { id: 'nine_6v1', format: 'forced_choice', prompt: 'Which feels more like you?',
    options: [
      { text: 'I notice threats and problems before other people do.', type: '6' },
      { text: 'I notice errors and what is being done wrong before other people do.', type: '1' },
    ]},
  { id: 'nine_6v9', format: 'forced_choice', prompt: 'Which feels more like you?',
    options: [
      { text: 'I am loyal to my people and will defend what we have built together.', type: '6' },
      { text: 'I want to keep the peace and not rock any boats.', type: '9' },
    ]},
  { id: 'nine_6v3', format: 'forced_choice', prompt: 'Which feels more like you?',
    options: [
      { text: 'I hesitate until I feel sure it is safe.', type: '6' },
      { text: 'I move forward decisively because I trust I can adapt.', type: '3' },
    ]},

  { id: 'nine_7v8', format: 'forced_choice', prompt: 'Which feels more like you?',
    options: [
      { text: 'I chase freedom — I do not want to feel confined or limited.', type: '7' },
      { text: 'I push against anything that tries to control me.', type: '8' },
    ]},
  { id: 'nine_7v2', format: 'forced_choice', prompt: 'Which feels more like you?',
    options: [
      { text: 'I fill my life with possibilities and bright futures.', type: '7' },
      { text: 'I fill my life with the people I care for.', type: '2' },
    ]},
  { id: 'nine_7v5', format: 'forced_choice', prompt: 'Which feels more like you?',
    options: [
      { text: 'I want to be where the action is.', type: '7' },
      { text: 'I want to be where I can think in peace.', type: '5' },
    ]},

  { id: 'nine_8v9', format: 'forced_choice', prompt: 'Which feels more like you?',
    options: [
      { text: 'I take up the space I need, even if it makes others uncomfortable.', type: '8' },
      { text: 'I soften myself so others are comfortable, even when it costs me.', type: '9' },
    ]},
  { id: 'nine_8v1', format: 'forced_choice', prompt: 'Which feels more like you?',
    options: [
      { text: 'I protect what is mine with force if necessary.', type: '8' },
      { text: 'I hold myself and others to a higher principle.', type: '1' },
    ]},
  { id: 'nine_8v3', format: 'forced_choice', prompt: 'Which feels more like you?',
    options: [
      { text: 'My instinct is to lead from power.', type: '8' },
      { text: 'My instinct is to lead from performance.', type: '3' },
    ]},

  { id: 'nine_9v1', format: 'forced_choice', prompt: 'Which feels more like you?',
    options: [
      { text: 'I avoid conflict because I do not want to disturb the peace.', type: '9' },
      { text: 'I engage conflict when something is being done wrong.', type: '1' },
    ]},
  { id: 'nine_9v6', format: 'forced_choice', prompt: 'Which feels more like you?',
    options: [
      { text: 'I go with the flow and tend to merge with what is around me.', type: '9' },
      { text: 'I stay alert and scan for what could go wrong.', type: '6' },
    ]},
  { id: 'nine_9v4', format: 'forced_choice', prompt: 'Which feels more like you?',
    options: [
      { text: 'I avoid drawing attention to my own preferences and moods.', type: '9' },
      { text: 'My preferences and moods are very present, whether I want them to be or not.', type: '4' },
    ]},
];

export const nineFramework: Framework = {
  id: 'nine',
  name: 'The Nine',
  tagline: 'Your core motivation',
  description: 'Underneath what you do is why you do it. Nine patterns of motivation, each with its own gifts and shadows — inspired by the Enneagram.',
  estimatedMinutes: 5,
  questions,
};

export function scoreNine(responses: Record<string, ForcedChoiceAnswer>): NineResult {
  const scores: Record<string, number> = { '1': 0, '2': 0, '3': 0, '4': 0, '5': 0, '6': 0, '7': 0, '8': 0, '9': 0 };

  for (const q of questions) {
    const answer = responses[q.id];
    if (!answer) continue;
    const chosenType = q.options[answer.value].type;
    scores[chosenType] = (scores[chosenType] || 0) + 1;
  }

  // Primary type = highest score
  const sorted = Object.entries(scores).sort((a, b) => b[1] - a[1]);
  const primaryType = parseInt(sorted[0][0], 10) as NineResult['type'];

  // Wing = highest of the two adjacent types
  const leftWing = primaryType === 1 ? 9 : primaryType - 1;
  const rightWing = primaryType === 9 ? 1 : primaryType + 1;
  const wing = (scores[String(leftWing)] >= scores[String(rightWing)] ? leftWing : rightWing) as NineResult['wing'];

  return {
    framework: 'nine',
    type: primaryType,
    wing,
    scores,
    summary: nineSummaries[`${primaryType}w${wing}`] ?? nineSummaries[String(primaryType)] ?? `Type ${primaryType} with a ${wing} wing.`,
  };
}

const nineSummaries: Record<string, string> = {
  '1': 'The reformer, seeking integrity in everything',
  '2': 'The helper, loving through service',
  '3': 'The achiever, shaping yourself to succeed',
  '4': 'The individualist, finding meaning in depth',
  '5': 'The investigator, understanding as protection',
  '6': 'The loyalist, vigilant and committed',
  '7': 'The enthusiast, chasing brightness',
  '8': 'The challenger, protecting through strength',
  '9': 'The peacemaker, holding the calm center',
  '5w4': 'The investigator with an artistic soul',
  '5w6': 'The investigator with a loyal heart',
  '4w5': 'The individualist with an analytical mind',
  '4w3': 'The individualist with ambition in their grief',
  '2w1': 'The helper with a principled streak',
  '2w3': 'The helper who needs to be seen',
  '3w2': 'The achiever who leads with warmth',
  '3w4': 'The achiever with hidden depths',
  '1w9': 'The reformer who reforms gently',
  '1w2': 'The reformer who advocates for others',
  '6w5': 'The loyalist who thinks before trusting',
  '6w7': 'The loyalist who lightens with humor',
  '7w6': 'The enthusiast anchored by loyalty',
  '7w8': 'The enthusiast with a commanding streak',
  '8w7': 'The challenger with an adventurous edge',
  '8w9': 'The challenger with a steady core',
  '9w8': 'The peacemaker with hidden strength',
  '9w1': 'The peacemaker with quiet convictions',
};
