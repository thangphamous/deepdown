import type { Framework, DualRankingQuestion, DualRankingAnswer, LoveLanguageResult } from './types';

// Five love languages, renamed slightly for trademark distance:
// - Words (affirmation, verbal appreciation)
// - Time (undivided attention)
// - Acts (helpful deeds, service)
// - Gifts (symbolic tokens)
// - Touch (physical closeness)
//
// 20 questions total: 10 give + 10 receive
// Each question is a ranking of 5 options, and the user does it twice
// (once from the giving perspective, once from the receiving perspective).
// For v1, we present this as 4 dual-ranking rounds, each containing all 5 languages.

interface LangOption {
  id: string;
  language: string;
  give_text: string;
  receive_text: string;
}

const LANGUAGES: LangOption[] = [
  {
    id: 'words',
    language: 'words',
    give_text: 'Telling someone exactly what I appreciate about them',
    receive_text: 'Being told specifically what I mean to someone',
  },
  {
    id: 'time',
    language: 'time',
    give_text: 'Giving someone my full, undistracted attention',
    receive_text: 'Someone putting their phone down and being fully with me',
  },
  {
    id: 'acts',
    language: 'acts',
    give_text: 'Doing something that makes their life lighter without being asked',
    receive_text: 'Someone taking care of something for me before I have to ask',
  },
  {
    id: 'gifts',
    language: 'gifts',
    give_text: 'Finding them something meaningful that made me think of them',
    receive_text: 'Receiving something small that shows someone thought of me',
  },
  {
    id: 'touch',
    language: 'touch',
    give_text: 'Offering a hug, a hand on the back, a real closeness',
    receive_text: 'A warm hug, holding hands, being physically close',
  },
];

// 4 rounds, always all 5 options
// We vary wording slightly in later rounds to keep it engaging
const ROUND_COUNT = 4;

const questions: DualRankingQuestion[] = Array.from({ length: ROUND_COUNT }, (_, idx) => ({
  id: `ll_round_${idx + 1}`,
  format: 'dual_ranking',
  prompts: {
    give: idx === 0
      ? 'How do you most naturally show love? Rank from most like you (top) to least (bottom).'
      : idx === 1
        ? 'When you want someone to feel loved by you, what do you reach for first?'
        : idx === 2
          ? 'When you love someone well, what are you usually doing?'
          : 'When someone you love is struggling, how do you most want to help?',
    receive: idx === 0
      ? 'How do you most feel loved? Rank from what makes you feel most loved (top) to least (bottom).'
      : idx === 1
        ? 'What fills your tank when you are feeling lonely or disconnected?'
        : idx === 2
          ? 'When someone has loved you really well, what did they do?'
          : 'When you are struggling, what do you most need from the people who love you?',
  },
  options: LANGUAGES.map((l) => ({
    id: l.id,
    language: l.language,
    text: l.give_text,
  })),
}));

export const loveLanguageFramework: Framework = {
  id: 'love_language',
  name: 'Love Language',
  tagline: 'How you love',
  description: 'The way you give love and the way you receive it — which are often different. Understanding both changes how you show up with the people closest to you.',
  estimatedMinutes: 4,
  questions,
};

export function scoreLoveLanguage(responses: Record<string, DualRankingAnswer>): LoveLanguageResult {
  const give_scores: Record<string, number> = { words: 0, time: 0, acts: 0, gifts: 0, touch: 0 };
  const receive_scores: Record<string, number> = { words: 0, time: 0, acts: 0, gifts: 0, touch: 0 };

  for (const q of questions) {
    const answer = responses[q.id];
    if (!answer) continue;
    answer.give.forEach((langId, rank) => {
      const points = LANGUAGES.length - rank;
      give_scores[langId] = (give_scores[langId] || 0) + points;
    });
    answer.receive.forEach((langId, rank) => {
      const points = LANGUAGES.length - rank;
      receive_scores[langId] = (receive_scores[langId] || 0) + points;
    });
  }

  const give_top = Object.entries(give_scores).sort((a, b) => b[1] - a[1])[0][0];
  const receive_top = Object.entries(receive_scores).sort((a, b) => b[1] - a[1])[0][0];

  const labels: Record<string, string> = {
    words: 'Words',
    time: 'Time',
    acts: 'Acts',
    gifts: 'Gifts',
    touch: 'Touch',
  };

  const summary = give_top === receive_top
    ? `You love and want to be loved the same way — through ${labels[give_top]}`
    : `You give love through ${labels[give_top]}, but you most feel loved through ${labels[receive_top]}`;

  return {
    framework: 'love_language',
    give_top: labels[give_top],
    receive_top: labels[receive_top],
    give_scores,
    receive_scores,
    summary,
  };
}
