// Core types for the deepdown assessment system

export type FrameworkId = 'ikigai' | 'nine' | 'archetype' | 'strengths' | 'frequencies' | 'love_language';

export type QuestionFormat =
  | 'likert'          // 1-5 agree/disagree
  | 'forced_choice'   // choose A or B
  | 'scenario'        // scenario + multi-option
  | 'dual_slider'     // two axes, 0-100 each
  | 'ranking'         // rank N options
  | 'dual_ranking';   // rank the same N options twice (give/receive)

export interface LikertQuestion {
  id: string;
  format: 'likert';
  prompt: string;
  dimension: string;        // which axis this loads on
  polarity: 1 | -1;         // does agreement support or oppose the dimension
}

export interface ForcedChoiceQuestion {
  id: string;
  format: 'forced_choice';
  prompt: string;
  options: [
    { text: string; type: string },
    { text: string; type: string }
  ];
}

export interface ScenarioQuestion {
  id: string;
  format: 'scenario';
  prompt: string;
  options: Array<{ text: string; frequency: string }>;
}

export interface DualSliderQuestion {
  id: string;
  format: 'dual_slider';
  prompt: string;            // the activity being rated
  axisA: { label: string; low: string; high: string }; // e.g., love ↔ indifferent
  axisB: { label: string; low: string; high: string }; // e.g., skilled ↔ struggle
}

export interface RankingQuestion {
  id: string;
  format: 'ranking';
  prompt: string;
  options: Array<{ id: string; text: string; theme: string }>;
}

export interface DualRankingQuestion {
  id: string;
  format: 'dual_ranking';
  prompts: { give: string; receive: string };
  options: Array<{ id: string; text: string; language: string }>;
}

export type Question =
  | LikertQuestion
  | ForcedChoiceQuestion
  | ScenarioQuestion
  | DualSliderQuestion
  | RankingQuestion
  | DualRankingQuestion;

// Answer types matching each question format
export type LikertAnswer = { value: 1 | 2 | 3 | 4 | 5 };
export type ForcedChoiceAnswer = { value: 0 | 1 };
export type ScenarioAnswer = { value: number }; // index of chosen option
export type DualSliderAnswer = { axisA: number; axisB: number }; // 0-100
export type RankingAnswer = { order: string[] }; // option ids in ranked order
export type DualRankingAnswer = { give: string[]; receive: string[] };

export type Answer =
  | LikertAnswer
  | ForcedChoiceAnswer
  | ScenarioAnswer
  | DualSliderAnswer
  | RankingAnswer
  | DualRankingAnswer;

// Framework definition
export interface Framework {
  id: FrameworkId;
  name: string;
  tagline: string;
  description: string;
  estimatedMinutes: number;
  questions: Question[];
}

// Results — each framework produces its own result shape
export interface IkigaiResult {
  framework: 'ikigai';
  quadrant: 'passion' | 'mission' | 'vocation' | 'profession';
  scores: { love: number; skilled: number; world_needs: number; paid_for: number };
  summary: string;
}

export interface NineResult {
  framework: 'nine';
  type: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9;
  wing: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9;
  scores: Record<string, number>;
  summary: string;
}

export interface ArchetypeResult {
  framework: 'archetype';
  type: string; // e.g., "INFJ"
  scores: { EI: number; SN: number; TF: number; JP: number }; // -100 to 100
  summary: string;
}

export interface StrengthsResult {
  framework: 'strengths';
  top5: string[];
  all_scores: Record<string, number>;
  domain_distribution: { thinking: number; relating: number; executing: number; influencing: number };
  summary: string;
}

export interface FrequenciesResult {
  framework: 'frequencies';
  primary: string;
  secondary: string;
  scores: Record<string, number>;
  summary: string;
}

export interface LoveLanguageResult {
  framework: 'love_language';
  give_top: string;
  receive_top: string;
  give_scores: Record<string, number>;
  receive_scores: Record<string, number>;
  summary: string;
}

export type FrameworkResult =
  | IkigaiResult
  | NineResult
  | ArchetypeResult
  | StrengthsResult
  | FrequenciesResult
  | LoveLanguageResult;

// The synthesized archetype
export interface Archetype {
  qualifier: string;
  role: string;
  full_name: string;  // "The Contemplative Builder"
  narrative: string;
  tags: string[];
}
