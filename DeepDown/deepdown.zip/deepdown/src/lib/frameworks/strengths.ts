import type { Framework, RankingQuestion, RankingAnswer, StrengthsResult } from './types';

// 24 talent themes across 4 domains (6 per domain)
// Thinking, Relating, Executing, Influencing

interface Theme {
  id: string;
  name: string;
  description: string;
  domain: 'thinking' | 'relating' | 'executing' | 'influencing';
}

const themes: Theme[] = [
  // Thinking
  { id: 'strategic', name: 'Strategic', description: 'You see patterns and paths through complexity others miss', domain: 'thinking' },
  { id: 'analytical', name: 'Analytical', description: 'You cut through to what is actually true', domain: 'thinking' },
  { id: 'learner', name: 'Learner', description: 'You are energized by the process of mastering new things', domain: 'thinking' },
  { id: 'input', name: 'Input', description: 'You collect knowledge, ideas, and resources others may need', domain: 'thinking' },
  { id: 'intellection', name: 'Intellection', description: 'You think for its own sake; ideas are companionship', domain: 'thinking' },
  { id: 'context', name: 'Context', description: 'You understand the present through the past', domain: 'thinking' },

  // Relating
  { id: 'empathy', name: 'Empathy', description: 'You feel what others feel almost before they do', domain: 'relating' },
  { id: 'connectedness', name: 'Connectedness', description: 'You see how everything is woven together', domain: 'relating' },
  { id: 'developer', name: 'Developer', description: 'You see potential in people and help them grow', domain: 'relating' },
  { id: 'harmony', name: 'Harmony', description: 'You find common ground and reduce friction', domain: 'relating' },
  { id: 'relator', name: 'Relator', description: 'You go deep with a few people rather than wide with many', domain: 'relating' },
  { id: 'includer', name: 'Includer', description: 'You make sure no one is left out', domain: 'relating' },

  // Executing
  { id: 'achiever', name: 'Achiever', description: 'You have an internal fire that wants to produce, always', domain: 'executing' },
  { id: 'responsibility', name: 'Responsibility', description: 'You take ownership of what you commit to', domain: 'executing' },
  { id: 'discipline', name: 'Discipline', description: 'You create order and routine to get things done', domain: 'executing' },
  { id: 'focus', name: 'Focus', description: 'You set a direction and drive toward it without distraction', domain: 'executing' },
  { id: 'restorative', name: 'Restorative', description: 'You love to fix what is broken', domain: 'executing' },
  { id: 'arranger', name: 'Arranger', description: 'You juggle many moving pieces and find the optimal configuration', domain: 'executing' },

  // Influencing
  { id: 'command', name: 'Command', description: 'You take charge and make decisions others avoid', domain: 'influencing' },
  { id: 'communication', name: 'Communication', description: 'You turn thoughts into words that move people', domain: 'influencing' },
  { id: 'activator', name: 'Activator', description: 'You turn ideas into action before others are ready', domain: 'influencing' },
  { id: 'woo', name: 'Woo', description: 'You win people over and turn strangers into allies', domain: 'influencing' },
  { id: 'significance', name: 'Significance', description: 'You want your work to matter and to be seen', domain: 'influencing' },
  { id: 'self_assurance', name: 'Self-Assurance', description: 'You trust your own judgment even when no one agrees', domain: 'influencing' },
];

// 6 rounds of adaptive ranking, 5 themes per round
// Rounds are designed so each theme appears in at least 1 round
// and strong themes will naturally rise to the top across rounds

const ROUNDS: string[][] = [
  ['strategic', 'empathy', 'achiever', 'communication', 'learner'],
  ['analytical', 'connectedness', 'responsibility', 'command', 'input'],
  ['intellection', 'developer', 'discipline', 'activator', 'context'],
  ['strategic', 'harmony', 'focus', 'woo', 'empathy'],
  ['learner', 'relator', 'restorative', 'significance', 'analytical'],
  ['input', 'includer', 'arranger', 'self_assurance', 'developer'],
];

const questions: RankingQuestion[] = ROUNDS.map((themeIds, idx) => ({
  id: `str_round_${idx + 1}`,
  format: 'ranking',
  prompt: 'Rank these from most like you (top) to least like you (bottom)',
  options: themeIds.map((id) => {
    const theme = themes.find((t) => t.id === id)!;
    return { id: theme.id, text: theme.description, theme: theme.id };
  }),
}));

export const strengthsFramework: Framework = {
  id: 'strengths',
  name: 'Strengths',
  tagline: 'Your top talents',
  description: 'What you do effortlessly well — your natural talents, not skills you had to learn. Your top 5 become the lens you see yourself through.',
  estimatedMinutes: 5,
  questions,
};

export function scoreStrengths(responses: Record<string, RankingAnswer>): StrengthsResult {
  // Score each theme based on where it ranked across the rounds it appeared in
  // Higher rank = higher score. Top of a 5-item ranking = 5 points, bottom = 1
  const scores: Record<string, number> = {};
  const appearances: Record<string, number> = {};

  themes.forEach((t) => {
    scores[t.id] = 0;
    appearances[t.id] = 0;
  });

  for (const question of questions) {
    const answer = responses[question.id];
    if (!answer) continue;
    answer.order.forEach((themeId, rank) => {
      const points = question.options.length - rank; // 5, 4, 3, 2, 1
      scores[themeId] = (scores[themeId] || 0) + points;
      appearances[themeId] = (appearances[themeId] || 0) + 1;
    });
  }

  // Normalize by appearances so themes in fewer rounds aren't penalized
  const normalized: Record<string, number> = {};
  for (const themeId of Object.keys(scores)) {
    const app = appearances[themeId] || 1;
    normalized[themeId] = scores[themeId] / app;
  }

  // Top 5
  const top5 = Object.entries(normalized)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([id]) => themes.find((t) => t.id === id)!.name);

  // Domain distribution across top 5
  const top5Themes = top5.map((name) => themes.find((t) => t.name === name)!);
  const distribution = { thinking: 0, relating: 0, executing: 0, influencing: 0 };
  top5Themes.forEach((t) => {
    distribution[t.domain] += 1;
  });

  const dominantDomain = Object.entries(distribution).sort((a, b) => b[1] - a[1])[0][0];
  const domainSummaries: Record<string, string> = {
    thinking: 'You lead with your mind — you make sense of the world before moving through it',
    relating: 'You lead with your heart — you tend to others with real attention',
    executing: 'You lead with action — you make things happen that would otherwise stall',
    influencing: 'You lead with presence — you move others toward your vision',
  };

  return {
    framework: 'strengths',
    top5,
    all_scores: normalized,
    domain_distribution: distribution,
    summary: domainSummaries[dominantDomain] || 'A balanced blend of strengths across domains',
  };
}
