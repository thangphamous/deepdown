import Link from 'next/link';
import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import { FRAMEWORKS, FRAMEWORK_ORDER } from '@/lib/frameworks';
import type { FrameworkResult, FrameworkId } from '@/lib/frameworks/types';
import { Button } from '@/components/Button';
import { ProgressBar } from '@/components/ProgressBar';
import { ShareButton } from './ShareButton';

export default async function ProfilePage() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login');

  const { data: profile } = await supabase
    .from('profiles')
    .select('*')
    .eq('user_id', user.id)
    .maybeSingle();

  const { data: userRow } = await supabase
    .from('users')
    .select('display_name, email')
    .eq('id', user.id)
    .maybeSingle();

  const results = (profile?.framework_results as unknown as Record<string, FrameworkResult>) || {};
  const completedFrameworks = Object.keys(results) as FrameworkId[];

  if (!profile || completedFrameworks.length === 0) {
    return (
      <div className="max-w-2xl mx-auto px-6 py-20 text-center">
        <h1 className="font-serif text-4xl mb-3">Your profile is waiting.</h1>
        <p className="text-lg text-mist mb-8">
          Complete at least one framework to see your archetype take shape.
        </p>
        <Link href="/app">
          <Button variant="dark" size="lg">Start a framework</Button>
        </Link>
      </div>
    );
  }

  const tags = buildTags(results);

  return (
    <div className="max-w-3xl mx-auto px-6 py-10 sm:py-14">
      <div className="relative rounded-xl overflow-hidden bg-hero-gradient text-white p-8 sm:p-10 mb-10">
        <div className="absolute top-8 right-8 h-24 w-24 rounded-full border border-white/20" />
        <div className="absolute top-16 right-16 h-10 w-10 rounded-full border border-glow/40" />
        <div className="absolute top-[4.75rem] right-[4.75rem] h-3 w-3 rounded-full bg-glow" />

        <p className="text-xs uppercase tracking-wider text-glow mb-3">Your archetype</p>
        <h1 className="font-serif text-4xl sm:text-5xl mb-4 leading-tight">
          {profile.archetype_name || 'Still composing…'}
        </h1>
        {profile.summary && (
          <p className="text-white/80 text-lg leading-relaxed mb-6 max-w-xl">{profile.summary}</p>
        )}
        <div className="flex flex-wrap gap-2">
          {tags.map((t) => (
            <span
              key={t}
              className="px-3 py-1 rounded-full bg-white/10 border border-white/20 text-xs text-white/90"
            >
              {t}
            </span>
          ))}
        </div>
      </div>

      <div className="mb-8 bg-white border border-faint rounded-lg p-4 flex items-center justify-between">
        <div>
          <p className="text-xs text-mist mb-1">Profile completion</p>
          <p className="text-sm text-ink">
            {completedFrameworks.length} of 6 frameworks complete
          </p>
        </div>
        <div className="flex-1 mx-6">
          <ProgressBar value={profile.completion_pct || 0} />
        </div>
        <span className="text-sm font-medium text-ink tabular-nums">{profile.completion_pct || 0}%</span>
      </div>

      <h2 className="text-sm font-medium text-mist uppercase tracking-wider mb-4">The six lenses</h2>
      <div className="grid sm:grid-cols-2 gap-3 mb-10">
        {FRAMEWORK_ORDER.map((id) => {
          const fw = FRAMEWORKS[id];
          const result = results[id];
          return (
            <div
              key={id}
              className="bg-white border border-faint rounded-lg p-4"
            >
              <div className="flex items-baseline justify-between mb-2">
                <p className="font-medium text-ink">{fw.name}</p>
                <span className="text-xs text-mist">{result ? frameworkBadge(result) : 'Not started'}</span>
              </div>
              <p className="text-sm text-mist leading-relaxed">
                {result ? result.summary : fw.tagline}
              </p>
              {!result && (
                <Link
                  href={`/app/assessment/${id}`}
                  className="inline-block text-xs text-current mt-3 hover:underline"
                >
                  Take now →
                </Link>
              )}
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-2 gap-3">
        <ShareButton />
        <Link href="/app">
          <Button variant="secondary" size="md" className="w-full">
            Back to dashboard
          </Button>
        </Link>
      </div>
    </div>
  );
}

function buildTags(results: Record<string, FrameworkResult>): string[] {
  const tags: string[] = [];
  const a = results.archetype as any;
  const n = results.nine as any;
  const s = results.strengths as any;
  const f = results.frequencies as any;
  const l = results.love_language as any;
  if (a?.type) tags.push(a.type);
  if (n?.type) tags.push(`Type ${n.type}w${n.wing}`);
  if (s?.top5?.[0]) tags.push(s.top5[0]);
  if (f?.primary) tags.push(`The ${capitalize(f.primary)}`);
  if (l?.give_top && l?.receive_top) tags.push(`${l.give_top} → ${l.receive_top}`);
  return tags;
}

function frameworkBadge(result: FrameworkResult): string {
  switch (result.framework) {
    case 'archetype': return result.type;
    case 'nine': return `${result.type}w${result.wing}`;
    case 'ikigai': return capitalize(result.quadrant);
    case 'strengths': return 'Top 5';
    case 'frequencies': return `The ${capitalize(result.primary)}`;
    case 'love_language': return `${result.give_top} → ${result.receive_top}`;
  }
}

function capitalize(s: string) {
  return s.charAt(0).toUpperCase() + s.slice(1);
}
