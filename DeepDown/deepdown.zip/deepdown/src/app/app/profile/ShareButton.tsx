'use client';

import { useState, useTransition } from 'react';
import { createShare } from '@/app/actions/assessments';
import { Button } from '@/components/Button';

export function ShareButton() {
  const [isPending, startTransition] = useTransition();
  const [url, setUrl] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const onClick = () => {
    startTransition(async () => {
      try {
        const { token } = await createShare();
        const site = typeof window !== 'undefined' ? window.location.origin : '';
        const link = `${site}/s/${token}`;
        setUrl(link);
        await navigator.clipboard.writeText(link);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      } catch (e) {
        console.error(e);
      }
    });
  };

  if (url) {
    return (
      <button
        onClick={onClick}
        className="h-10 px-4 rounded-md bg-abyss hover:bg-deep text-white text-sm font-medium transition-colors w-full"
      >
        {copied ? 'Link copied ✓' : 'Share again'}
      </button>
    );
  }

  return (
    <Button variant="dark" size="md" className="w-full" onClick={onClick} disabled={isPending}>
      {isPending ? 'Creating link…' : 'Share my deepdown'}
    </Button>
  );
}
