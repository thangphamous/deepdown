import Link from 'next/link';
import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import { Wordmark } from '@/components/Logo';
import { SignOutButton } from './SignOutButton';

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login');

  const { data: profile } = await supabase
    .from('profiles')
    .select('completion_pct, archetype_name')
    .eq('user_id', user.id)
    .maybeSingle();

  return (
    <div className="min-h-screen bg-surface">
      <header className="border-b border-faint bg-white sticky top-0 z-10">
        <div className="max-w-5xl mx-auto px-6 h-14 flex items-center justify-between">
          <Link href="/app" className="text-ink">
            <Wordmark />
          </Link>
          <nav className="flex items-center gap-6">
            <Link href="/app" className="text-sm text-mist hover:text-ink transition-colors">
              Dashboard
            </Link>
            <Link href="/app/profile" className="text-sm text-mist hover:text-ink transition-colors">
              Profile
            </Link>
            <SignOutButton />
          </nav>
        </div>
      </header>
      <main>{children}</main>
    </div>
  );
}
