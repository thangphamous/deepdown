import Link from 'next/link';
import { createClient } from '@/lib/supabase/server';
import { FRAMEWORKS, FRAMEWORK_ORDER } from '@/lib/frameworks';
import { ProgressBar } from '@/components/ProgressBar';
import { Button } from '@/components/Button';

export default async function DashboardPage() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;

  const { data: userRow } = await supabase
    .from('users')
    .select('display_name')
    .eq('id', user.id)
    .maybeSingle();

  const { data: assessments } = await supabase
    .from('assessments')
    .select('framework_id, status, completed_at, updated_at')
    .eq('user_id', user.id)
    .order('updated_at', { ascending: false });

  const { data: profile } = await supabase
    .from('profiles')
    .select('archetype_name, completion_pct, summary')
    .eq('user_id', user.id)
    .maybeSingle();

  const statusByFramework = new Map<string, { status: string; completed_at: string | null }>();
  for (const a of assessments ?? []) {
    const existing = statusByFramework.get(a.framework_id);
    if (!existing || (a.status === 'completed' && existing.status !== 'completed')) {
      statusByFramework.set(a.framework_id, { status: a.status, completed_at: a.completed_at });
    }
  }

  const completed = FRAMEWORK_ORDER.filter((id) => statusByFramework.get(id)?.status === 'completed').length;
  const nextFramework = FRAMEWORK_ORDER.find((id) => statusByFramework.get(id)?.status !== 'completed');

  const firstName = userRow?.display_name?.split(' ')[0];

  return (
    <div className="max-w-3xl mx-auto px-6 py-10 sm:py-14">
      <div className="mb-10">
        <h1 className="font-serif text-4xl sm:text-5xl leading-tight mb-2 text-balance">
          {completed === 0
            ? firstName ? `Welcome, ${firstName}.` : 'Welcome.'
            : completed === 6
              ? firstName ? `Well done, ${firstName}.` : 'Well done.'
              : firstName ? `Keep going, ${firstName}.` : 'Keep going.'}
        </h1>
        <p className="text-lg text-mist leading-relaxed text-balance">
          {completed === 0
            ? 'Start with any framework — each one takes about five minutes.'
            : completed === 6
              ? 'All six frameworks complete. Your portrait is ready.'
              : `${completed} of 6 frameworks complete. ${6 - completed} left to go.`}
        </p>
      </div>

      {profile?.archetype_name && completed > 0 && (
        <Link href="/app/profile" className="block mb-10">
          <div className="relative rounded-xl overflow-hidden bg-hero-gradient text-white p-8 hover:brightness-110 transition-all">
            <div className="absolute top-6 right-6 h-20 w-20 rounded-full border border-white/20" />
            <div className="absolute top-12 right-12 h-8 w-8 rounded-full bg-glow/50" />
            <p className="text-xs uppercase tracking-wider text-glow mb-2">Your archetype</p>
            <p className="font-serif text-3xl mb-2 leading-tight">{profile.archetype_name}</p>
            {profile.summary && (
              <p className="text-white/70 text-sm max-w-lg leading-relaxed mb-4">{profile.summary}</p>
            )}
            <div className="flex items-center gap-3">
              <ProgressBar value={profile.completion_pct || 0} className="flex-1 bg-white/10" />
              <span className="text-xs text-white/60 tabular-nums">{profile.completion_pct}%</span>
            </div>
          </div>
        </Link>
      )}

      <div className="mb-4 flex items-baseline justify-between">
        <h2 className="text-sm font-medium text-mist uppercase tracking-wider">The six lenses</h2>
        {nextFramework && (
          <Link href={`/app/assessment/${nextFramework}`}>
            <Button size="sm" variant="dark">
              {completed === 0 ? 'Start the first one' : 'Continue'}
            </Button>
          </Link>
        )}
      </div>

      <div className="space-y-2">
        {FRAMEWORK_ORDER.map((id) => {
          const fw = FRAMEWORKS[id];
          const status = statusByFramework.get(id)?.status || 'not_started';
          const isComplete = status === 'completed';
          const isInProgress = status === 'in_progress';
          return (
            <Link
              key={id}
              href={`/app/assessment/${id}`}
              className="block bg-white border border-faint rounded-lg p-4 hover:border-mist transition-all"
            >
              <div className="flex items-center gap-4">
                <div className={`h-10 w-10 rounded-full flex items-center justify-center flex-shrink-0 ${isComplete ? 'bg-glow text-abyss' : 'bg-surface text-mist'}`}>
                  {isComplete ? '✓' : <span className="text-xs">{String(FRAMEWORK_ORDER.indexOf(id) + 1).padStart(2, '0')}</span>}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-baseline gap-2">
                    <p className="font-medium text-ink">{fw.name}</p>
                    {isInProgress && <span className="text-xs text-current">· in progress</span>}
                  </div>
                  <p className="text-sm text-mist truncate">{fw.tagline}</p>
                </div>
                <span className="text-xs text-mist flex-shrink-0">
                  {isComplete ? 'Complete' : `${fw.estimatedMinutes} min`}
                </span>
              </div>
            </Link>
          );
        })}
      </div>

      {completed === 6 && (
        <div className="mt-10 p-6 bg-white border border-faint rounded-lg text-center">
          <p className="font-serif text-2xl mb-2">Your deepdown is complete.</p>
          <p className="text-sm text-mist mb-4">See your full portrait, share with others, or retake any framework to track growth over time.</p>
          <Link href="/app/profile">
            <Button variant="dark">See your profile</Button>
          </Link>
        </div>
      )}
    </div>
  );
}
