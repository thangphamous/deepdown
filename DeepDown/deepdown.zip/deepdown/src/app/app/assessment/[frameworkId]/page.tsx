import Link from 'next/link';
import { notFound, redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import { FRAMEWORKS } from '@/lib/frameworks';
import type { FrameworkId, Answer } from '@/lib/frameworks/types';
import { AssessmentRunner } from '@/components/AssessmentRunner';
import { startAssessment } from '@/app/actions/assessments';
import { Button } from '@/components/Button';

export default async function AssessmentPage({
  params,
  searchParams,
}: {
  params: { frameworkId: string };
  searchParams: { start?: string };
}) {
  const frameworkId = params.frameworkId as FrameworkId;
  const framework = FRAMEWORKS[frameworkId];
  if (!framework) notFound();

  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login');

  // Check if already complete
  const { data: completed } = await supabase
    .from('assessments')
    .select('id')
    .eq('user_id', user.id)
    .eq('framework_id', frameworkId)
    .eq('status', 'completed')
    .maybeSingle();

  if (searchParams.start !== '1') {
    return (
      <div className="max-w-2xl mx-auto px-6 py-12 sm:py-20">
        <p className="text-xs uppercase tracking-wider text-current font-medium mb-3">
          {completed ? 'Retake' : 'Framework'}
        </p>
        <h1 className="font-serif text-4xl sm:text-5xl leading-tight mb-4 text-balance">{framework.name}</h1>
        <p className="text-xl text-mist mb-2">{framework.tagline}</p>
        <p className="text-base text-mist leading-relaxed mb-10 text-balance">{framework.description}</p>

        <div className="grid grid-cols-2 gap-4 mb-10">
          <div className="p-4 bg-white border border-faint rounded-lg">
            <p className="text-xs text-mist mb-1">Questions</p>
            <p className="text-2xl font-serif">{framework.questions.length}</p>
          </div>
          <div className="p-4 bg-white border border-faint rounded-lg">
            <p className="text-xs text-mist mb-1">Time</p>
            <p className="text-2xl font-serif">~{framework.estimatedMinutes} min</p>
          </div>
        </div>

        <div className="mb-6 p-4 bg-white border border-faint rounded-lg text-sm text-mist leading-relaxed">
          <p className="mb-2 text-ink font-medium">A few things to keep in mind</p>
          <ul className="space-y-1 list-disc pl-5">
            <li>Answer with your first instinct. Overthinking usually produces worse answers.</li>
            <li>Your answers save as you go — you can leave and come back.</li>
            <li>There are no right answers. There is only what is true for you.</li>
          </ul>
        </div>

        <div className="flex items-center gap-3">
          <Link href={`/app/assessment/${frameworkId}?start=1`}>
            <Button variant="dark" size="lg">
              {completed ? 'Retake' : 'Begin'}
            </Button>
          </Link>
          <Link href="/app">
            <Button variant="ghost" size="lg">Back to dashboard</Button>
          </Link>
        </div>
      </div>
    );
  }

  // Start (or resume) the assessment
  const { assessmentId } = await startAssessment(frameworkId);

  // Load existing responses
  const { data: existing } = await supabase
    .from('responses')
    .select('question_id, answer')
    .eq('assessment_id', assessmentId);

  const initial: Record<string, Answer> = {};
  for (const r of existing ?? []) {
    initial[r.question_id] = r.answer as Answer;
  }

  return <AssessmentRunner framework={framework} assessmentId={assessmentId} initialResponses={initial} />;
}
