import Link from 'next/link';
import { notFound, redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import { FRAMEWORKS, FRAMEWORK_ORDER } from '@/lib/frameworks';
import type { FrameworkId, FrameworkResult } from '@/lib/frameworks/types';
import { Button } from '@/components/Button';

export default async function AssessmentCompletePage({
  params,
}: {
  params: { frameworkId: string };
}) {
  const frameworkId = params.frameworkId as FrameworkId;
  const framework = FRAMEWORKS[frameworkId];
  if (!framework) notFound();

  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login');

  const { data: assessment } = await supabase
    .from('assessments')
    .select('result')
    .eq('user_id', user.id)
    .eq('framework_id', frameworkId)
    .eq('status', 'completed')
    .order('completed_at', { ascending: false })
    .limit(1)
    .maybeSingle();

  if (!assessment?.result) redirect(`/app/assessment/${frameworkId}`);

  const result = assessment.result as unknown as FrameworkResult;

  // Find next uncompleted framework
  const { data: all } = await supabase
    .from('assessments')
    .select('framework_id, status')
    .eq('user_id', user.id)
    .eq('status', 'completed');
  const completedSet = new Set(all?.map((a) => a.framework_id) ?? []);
  const nextFramework = FRAMEWORK_ORDER.find((id) => !completedSet.has(id));

  return (
    <div className="max-w-2xl mx-auto px-6 py-16 sm:py-24">
      <div className="text-center mb-12 animate-slide-up">
        <p className="text-xs uppercase tracking-wider text-current font-medium mb-3">
          {framework.name} · complete
        </p>

        <div className="mb-8">
          {renderResult(result)}
        </div>

        <p className="text-lg text-mist leading-relaxed max-w-md mx-auto text-balance">
          {result.summary}
        </p>
      </div>

      <div className="flex items-center justify-center gap-3">
        {nextFramework ? (
          <Link href={`/app/assessment/${nextFramework}`}>
            <Button variant="dark" size="lg">
              Next: {FRAMEWORKS[nextFramework].name}
            </Button>
          </Link>
        ) : (
          <Link href="/app/profile">
            <Button variant="dark" size="lg">See your full profile</Button>
          </Link>
        )}
        <Link href="/app">
          <Button variant="ghost" size="lg">Dashboard</Button>
        </Link>
      </div>
    </div>
  );
}

function renderResult(result: FrameworkResult) {
  switch (result.framework) {
    case 'archetype':
      return <h1 className="font-serif text-6xl sm:text-7xl text-abyss">{result.type}</h1>;
    case 'nine':
      return <h1 className="font-serif text-6xl sm:text-7xl text-abyss">Type {result.type}<span className="text-glow">w{result.wing}</span></h1>;
    case 'ikigai':
      return (
        <div>
          <h1 className="font-serif text-5xl sm:text-6xl text-abyss capitalize mb-2">{result.quadrant}</h1>
          <p className="text-sm text-mist">your dominant quadrant</p>
        </div>
      );
    case 'strengths':
      return (
        <div>
          <h1 className="font-serif text-3xl sm:text-4xl text-abyss mb-3">Your top five</h1>
          <div className="flex flex-wrap items-center justify-center gap-2">
            {result.top5.map((s, i) => (
              <span key={s} className="px-3 py-1 rounded-full bg-abyss text-white text-sm">
                {i + 1}. {s}
              </span>
            ))}
          </div>
        </div>
      );
    case 'frequencies':
      return (
        <div>
          <h1 className="font-serif text-5xl sm:text-6xl text-abyss capitalize">{result.primary}</h1>
          <p className="text-sm text-mist mt-2">with a secondary resonance of <span className="text-ink capitalize">{result.secondary}</span></p>
        </div>
      );
    case 'love_language':
      return (
        <div>
          <h1 className="font-serif text-4xl sm:text-5xl text-abyss">
            {result.give_top} <span className="text-glow">→</span> {result.receive_top}
          </h1>
          <p className="text-sm text-mist mt-3">how you give · how you receive</p>
        </div>
      );
  }
}
