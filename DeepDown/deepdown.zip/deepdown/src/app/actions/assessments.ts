'use server';

import { revalidatePath } from 'next/cache';
import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import {
  FRAMEWORKS,
  scoreFramework,
  type FrameworkId,
  type Answer,
  type FrameworkResult,
} from '@/lib/frameworks';
import { composeArchetype, calculateCompletion } from '@/lib/frameworks/synthesis';

/**
 * Start (or resume) an assessment. Returns the assessment id and any existing responses.
 */
export async function startAssessment(frameworkId: FrameworkId) {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error('Not authenticated');

  // Find existing in-progress assessment
  const { data: existing } = await supabase
    .from('assessments')
    .select('*')
    .eq('user_id', user.id)
    .eq('framework_id', frameworkId)
    .eq('status', 'in_progress')
    .maybeSingle();

  if (existing) {
    return { assessmentId: existing.id };
  }

  // Create new
  const { data: created, error } = await supabase
    .from('assessments')
    .insert({ user_id: user.id, framework_id: frameworkId, status: 'in_progress' })
    .select('id')
    .single();

  if (error) throw error;
  return { assessmentId: created.id };
}

/**
 * Save a single question response. Uses upsert so users can change answers.
 */
export async function saveResponse(
  assessmentId: string,
  questionId: string,
  answer: Answer,
) {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error('Not authenticated');

  // Check existing
  const { data: existing } = await supabase
    .from('responses')
    .select('id')
    .eq('assessment_id', assessmentId)
    .eq('question_id', questionId)
    .maybeSingle();

  if (existing) {
    const { error } = await supabase
      .from('responses')
      .update({ answer: answer as any })
      .eq('id', existing.id);
    if (error) throw error;
  } else {
    const { error } = await supabase
      .from('responses')
      .insert({ assessment_id: assessmentId, question_id: questionId, answer: answer as any });
    if (error) throw error;
  }

  return { ok: true };
}

/**
 * Complete an assessment: fetch all responses, score it, save the result,
 * and trigger profile re-synthesis.
 */
export async function completeAssessment(assessmentId: string) {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error('Not authenticated');

  const { data: assessment, error: assessmentErr } = await supabase
    .from('assessments')
    .select('*')
    .eq('id', assessmentId)
    .single();
  if (assessmentErr || !assessment) throw new Error('Assessment not found');
  if (assessment.user_id !== user.id) throw new Error('Not authorized');

  const { data: responses, error: respErr } = await supabase
    .from('responses')
    .select('question_id, answer')
    .eq('assessment_id', assessmentId);
  if (respErr) throw respErr;

  // Build the response map and score
  const responseMap: Record<string, Answer> = {};
  for (const r of responses || []) {
    responseMap[r.question_id] = r.answer as Answer;
  }

  const result = scoreFramework(assessment.framework_id as FrameworkId, responseMap);

  const { error: updateErr } = await supabase
    .from('assessments')
    .update({
      status: 'completed',
      result: result as any,
      completed_at: new Date().toISOString(),
    })
    .eq('id', assessmentId);
  if (updateErr) throw updateErr;

  // Re-synthesize the profile
  await synthesizeProfile(user.id);

  revalidatePath('/app');
  revalidatePath('/app/profile');

  return { ok: true, result };
}

/**
 * Re-synthesize a user's profile by pulling all completed assessments
 * and running the synthesis engine.
 */
export async function synthesizeProfile(userId: string) {
  const supabase = createClient();

  const { data: completed } = await supabase
    .from('assessments')
    .select('framework_id, result')
    .eq('user_id', userId)
    .eq('status', 'completed');

  if (!completed) return;

  const results: Record<string, FrameworkResult> = {};
  for (const a of completed) {
    if (a.result) {
      results[a.framework_id] = a.result as unknown as FrameworkResult;
    }
  }

  const partial = {
    archetype: results.archetype as any,
    nine: results.nine as any,
    ikigai: results.ikigai as any,
    strengths: results.strengths as any,
    frequencies: results.frequencies as any,
    love_language: results.love_language as any,
  };

  const completion = calculateCompletion(partial);
  const archetype = completion > 0 ? composeArchetype(partial) : null;

  // Fetch the profile
  const { data: profile } = await supabase
    .from('profiles')
    .select('id')
    .eq('user_id', userId)
    .single();
  if (!profile) return;

  await supabase
    .from('profiles')
    .update({
      archetype_name: archetype?.full_name || null,
      summary: archetype?.narrative || null,
      framework_results: results as any,
      completion_pct: completion,
      last_synthesized_at: new Date().toISOString(),
    })
    .eq('id', profile.id);

  if (archetype) {
    await supabase.from('archetypes').insert({
      profile_id: profile.id,
      qualifier: archetype.qualifier,
      role: archetype.role,
      narrative: archetype.narrative,
      framework_snapshot: results as any,
    });
  }
}

/**
 * Create a share link for the current user's profile.
 */
export async function createShare(permissions?: Record<string, unknown>) {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error('Not authenticated');

  const { data, error } = await supabase
    .from('shares')
    .insert({
      from_user_id: user.id,
      permissions: (permissions as any) || { frameworks: 'all', narrative: true },
    })
    .select('share_token')
    .single();

  if (error) throw error;
  return { token: data.share_token };
}

/**
 * Sign out.
 */
export async function signOut() {
  const supabase = createClient();
  await supabase.auth.signOut();
  redirect('/');
}
