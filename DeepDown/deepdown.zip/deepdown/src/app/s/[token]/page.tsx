import Link from 'next/link';
import { notFound } from 'next/navigation';
import { createServiceClient } from '@/lib/supabase/service';
import { FRAMEWORKS, FRAMEWORK_ORDER } from '@/lib/frameworks';
import type { FrameworkResult, FrameworkId } from '@/lib/frameworks/types';
import { Wordmark } from '@/components/Logo';
import { Button } from '@/components/Button';

export default async function SharePage({ params }: { params: { token: string } }) {
  // Use service role to bypass RLS (token is the authorization)
  const supabase = createServiceClient();

  const { data: share } = await supabase
    .from('shares')
    .select('from_user_id, permissions, expires_at')
    .eq('share_token', params.token)
    .maybeSingle();

  if (!share) notFound();
  if (share.expires_at && new Date(share.expires_at) < new Date()) notFound();

  const { data: profile } = await supabase
    .from('profiles')
    .select('archetype_name, summary, framework_results, completion_pct')
    .eq('user_id', share.from_user_id)
    .maybeSingle();

  const { data: sharer } = await supabase
    .from('users')
    .select('display_name')
    .eq('id', share.from_user_id)
    .maybeSingle();

  if (!profile?.archetype_name) {
    return (
      <div className="min-h-screen bg-surface flex items-center justify-center">
        <p className="text-mist">This deepdown is still being composed.</p>
      </div>
    );
  }

  // Update viewed_at (fire and forget)
  supabase.from('shares').update({ viewed_at: new Date().toISOString() }).eq('share_token', params.token).then();

  const results = (profile.framework_results as unknown as Record<string, FrameworkResult>) || {};
  const name = sharer?.display_name?.split(' ')[0] || 'Someone';
  const tags = buildTags(results);

  return (
    <div className="min-h-screen bg-surface flex flex-col">
      <header className="border-b border-faint bg-white">
        <div className="max-w-4xl mx-auto px-6 h-16 flex items-center justify-between">
          <Link href="/"><Wordmark className="text-ink" /></Link>
          <Link href="/signup">
            <Button variant="dark" size="sm">Create yours</Button>
          </Link>
        </div>
      </header>

      <main className="flex-1">
        <div className="max-w-2xl mx-auto px-6 py-10 sm:py-14">
          <p className="text-sm text-mist mb-6">{name} shared their deepdown with you.</p>

          <div className="relative rounded-xl overflow-hidden bg-hero-gradient text-white p-8 sm:p-10 mb-10">
            <div className="absolute top-8 right-8 h-24 w-24 rounded-full border border-white/20" />
            <div className="absolute top-16 right-16 h-10 w-10 rounded-full border border-glow/40" />
            <div className="absolute top-[4.75rem] right-[4.75rem] h-3 w-3 rounded-full bg-glow" />
            <p className="text-xs uppercase tracking-wider text-glow mb-3">Archetype</p>
            <h1 className="font-serif text-4xl sm:text-5xl mb-4 leading-tight">{profile.archetype_name}</h1>
            {profile.summary && (
              <p className="text-white/80 text-lg leading-relaxed mb-6 max-w-xl">{profile.summary}</p>
            )}
            <div className="flex flex-wrap gap-2">
              {tags.map((t) => (
                <span key={t} className="px-3 py-1 rounded-full bg-white/10 border border-white/20 text-xs text-white/90">
                  {t}
                </span>
              ))}
            </div>
          </div>

          <h2 className="text-sm font-medium text-mist uppercase tracking-wider mb-4">The six lenses</h2>
          <div className="grid sm:grid-cols-2 gap-3 mb-12">
            {FRAMEWORK_ORDER.map((id) => {
              const fw = FRAMEWORKS[id];
              const result = results[id];
              if (!result) return null;
              return (
                <div key={id} className="bg-white border border-faint rounded-lg p-4">
                  <div className="flex items-baseline justify-between mb-2">
                    <p className="font-medium text-ink">{fw.name}</p>
                    <span className="text-xs text-mist">{frameworkBadge(result)}</span>
                  </div>
                  <p className="text-sm text-mist leading-relaxed">{result.summary}</p>
                </div>
              );
            })}
          </div>

          <div className="rounded-lg bg-white border border-faint p-6 text-center">
            <p className="font-serif text-2xl mb-2">Curious about your own?</p>
            <p className="text-sm text-mist mb-5">Six frameworks. One unified portrait of who you are.</p>
            <Link href="/signup">
              <Button variant="dark" size="md">Start your deepdown</Button>
            </Link>
          </div>
        </div>
      </main>
    </div>
  );
}

function buildTags(results: Record<string, FrameworkResult>): string[] {
  const tags: string[] = [];
  const a = results.archetype as any;
  const n = results.nine as any;
  const s = results.strengths as any;
  const f = results.frequencies as any;
  const l = results.love_language as any;
  if (a?.type) tags.push(a.type);
  if (n?.type) tags.push(`Type ${n.type}w${n.wing}`);
  if (s?.top5?.[0]) tags.push(s.top5[0]);
  if (f?.primary) tags.push(`The ${capitalize(f.primary)}`);
  if (l?.give_top && l?.receive_top) tags.push(`${l.give_top} → ${l.receive_top}`);
  return tags;
}

function frameworkBadge(result: FrameworkResult): string {
  switch (result.framework) {
    case 'archetype': return result.type;
    case 'nine': return `${result.type}w${result.wing}`;
    case 'ikigai': return capitalize(result.quadrant);
    case 'strengths': return 'Top 5';
    case 'frequencies': return `The ${capitalize(result.primary)}`;
    case 'love_language': return `${result.give_top} → ${result.receive_top}`;
  }
}

function capitalize(s: string) {
  return s.charAt(0).toUpperCase() + s.slice(1);
}
