import { Suspense } from 'react';
import Link from 'next/link';
import { Wordmark } from '@/components/Logo';
import { LoginForm } from '../login/LoginForm';

export default function SignupPage() {
  return (
    <div className="min-h-screen flex flex-col bg-surface">
      <header className="border-b border-faint bg-white">
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center">
          <Link href="/"><Wordmark className="text-ink" /></Link>
        </div>
      </header>

      <main className="flex-1 flex items-center justify-center px-6 py-12">
        <div className="w-full max-w-sm">
          <h1 className="font-serif text-3xl mb-1 text-center">Start your deepdown</h1>
          <p className="text-sm text-mist text-center mb-8">Six frameworks · one portrait · ~30 minutes</p>

          <Suspense fallback={<div className="text-sm text-mist text-center">Loading…</div>}>
            <LoginForm />
          </Suspense>

          <p className="text-sm text-mist text-center mt-8">
            Already have an account?{' '}
            <Link href="/login" className="text-current hover:underline font-medium">
              Sign in
            </Link>
          </p>
        </div>
      </main>
    </div>
  );
}
