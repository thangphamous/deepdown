import Link from 'next/link';
import { Wordmark } from '@/components/Logo';
import { Button } from '@/components/Button';

export default function NotFound() {
  return (
    <div className="min-h-screen bg-surface flex flex-col">
      <header className="border-b border-faint bg-white">
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center">
          <Link href="/"><Wordmark className="text-ink" /></Link>
        </div>
      </header>
      <main className="flex-1 flex items-center justify-center px-6 text-center">
        <div className="max-w-md">
          <h1 className="font-serif text-5xl mb-3">Not found</h1>
          <p className="text-mist mb-6">This page doesn&apos;t exist — or the link has expired.</p>
          <Link href="/"><Button variant="dark">Back home</Button></Link>
        </div>
      </main>
    </div>
  );
}
