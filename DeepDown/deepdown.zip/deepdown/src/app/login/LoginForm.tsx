'use client';

import { useState } from 'react';
import { useSearchParams } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import { Button } from '@/components/Button';

export function LoginForm() {
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState<'idle' | 'sending' | 'sent' | 'error'>('idle');
  const [error, setError] = useState<string | null>(null);
  const searchParams = useSearchParams();
  const next = searchParams.get('next') || '/app';

  const supabase = createClient();

  const siteUrl =
    typeof window !== 'undefined'
      ? window.location.origin
      : process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000';

  const signInWithEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('sending');
    setError(null);
    const { error } = await supabase.auth.signInWithOtp({
      email,
      options: {
        emailRedirectTo: `${siteUrl}/auth/callback?next=${encodeURIComponent(next)}`,
      },
    });
    if (error) {
      setError(error.message);
      setStatus('error');
    } else {
      setStatus('sent');
    }
  };

  const signInWithGoogle = async () => {
    await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: `${siteUrl}/auth/callback?next=${encodeURIComponent(next)}`,
      },
    });
  };

  if (status === 'sent') {
    return (
      <div className="p-4 rounded-md bg-white border border-faint text-center">
        <p className="text-sm text-ink mb-1 font-medium">Check your email</p>
        <p className="text-xs text-mist">We sent a magic link to {email}</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <Button variant="secondary" size="lg" onClick={signInWithGoogle} className="w-full">
        Continue with Google
      </Button>

      <div className="relative">
        <div className="absolute inset-0 flex items-center">
          <div className="w-full border-t border-faint" />
        </div>
        <div className="relative flex justify-center text-xs">
          <span className="px-3 bg-surface text-mist">or</span>
        </div>
      </div>

      <form onSubmit={signInWithEmail} className="space-y-3">
        <input
          type="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="you@example.com"
          className="w-full h-10 px-3 rounded-md border border-faint bg-white text-sm focus:outline-none focus:ring-2 focus:ring-current focus:border-current"
        />
        <Button type="submit" variant="dark" size="lg" disabled={status === 'sending'} className="w-full">
          {status === 'sending' ? 'Sending…' : 'Send magic link'}
        </Button>
      </form>

      {error && (
        <p className="text-sm text-red-600 text-center">{error}</p>
      )}
    </div>
  );
}
