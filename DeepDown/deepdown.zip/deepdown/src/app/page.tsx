import Link from 'next/link';
import { Logo, Wordmark } from '@/components/Logo';
import { Button } from '@/components/Button';

export default function LandingPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b border-faint bg-white">
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          <Wordmark className="text-ink" />
          <div className="flex items-center gap-2">
            <Link href="/login">
              <Button variant="ghost" size="sm">Sign in</Button>
            </Link>
            <Link href="/signup">
              <Button variant="dark" size="sm">Get started</Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="flex-1">
        <section className="bg-hero-gradient text-white">
          <div className="max-w-4xl mx-auto px-6 py-24 sm:py-32 text-center">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-xs mb-8 text-glow">
              <span className="h-1.5 w-1.5 rounded-full bg-glow" />
              Now in beta
            </div>
            <h1 className="font-serif text-5xl sm:text-7xl leading-tight mb-6 text-balance">
              How deep <em className="italic text-glow">will</em> you go?
            </h1>
            <p className="text-lg sm:text-xl text-white/70 max-w-2xl mx-auto mb-10 text-balance leading-relaxed">
              A map of who you are, beneath the surface. Six personality frameworks synthesized into one unified portrait of you.
            </p>
            <div className="flex items-center justify-center gap-3">
              <Link href="/signup">
                <Button size="lg" className="bg-glow hover:bg-glowDark text-abyss">
                  Start your deepdown
                </Button>
              </Link>
              <Link href="#how">
                <Button variant="ghost" size="lg" className="text-white hover:bg-white/10">
                  How it works
                </Button>
              </Link>
            </div>
            <p className="text-xs text-white/40 mt-8">~30 minutes · all six frameworks</p>
          </div>
        </section>

        <section id="how" className="bg-white border-b border-faint">
          <div className="max-w-5xl mx-auto px-6 py-20">
            <div className="max-w-2xl mb-12">
              <p className="text-xs uppercase tracking-wider text-current font-medium mb-3">Six lenses</p>
              <h2 className="font-serif text-4xl leading-tight mb-4 text-balance">
                One portrait, composed from the best frameworks ever made.
              </h2>
              <p className="text-lg text-mist leading-relaxed">
                Each framework answers a different question about who you are. deepdown combines all six into a single archetype — the thing no other platform does.
              </p>
            </div>

            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {FRAMEWORK_CARDS.map((f) => (
                <div
                  key={f.name}
                  className="p-5 rounded-lg border border-faint bg-white"
                >
                  <p className="text-sm font-medium text-ink mb-1">{f.name}</p>
                  <p className="text-sm text-mist leading-relaxed">{f.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="bg-surface">
          <div className="max-w-5xl mx-auto px-6 py-20">
            <div className="max-w-2xl mb-10">
              <p className="text-xs uppercase tracking-wider text-current font-medium mb-3">The synthesis</p>
              <h2 className="font-serif text-4xl leading-tight mb-4 text-balance">
                You are not a four-letter code. You are everything at once.
              </h2>
              <p className="text-lg text-mist leading-relaxed">
                Other tests give you one label. deepdown composes your archetype from the full picture — your cognitive style, your core motivation, your strengths, your purpose, your frequency, and how you love.
              </p>
            </div>

            <div className="relative rounded-xl overflow-hidden bg-hero-gradient text-white p-10 sm:p-14">
              <div className="absolute top-10 right-10 h-24 w-24 rounded-full border border-white/20" />
              <div className="absolute top-20 right-20 h-12 w-12 rounded-full border border-glow/40" />
              <div className="absolute top-[7rem] right-[6.5rem] h-3 w-3 rounded-full bg-glow" />
              <p className="text-xs uppercase tracking-wider text-glow mb-3">Your archetype</p>
              <p className="font-serif text-4xl sm:text-5xl mb-3 leading-tight">The Contemplative Builder</p>
              <p className="text-white/70 text-lg mb-6 max-w-2xl leading-relaxed">
                You move through the world with quiet conviction — watching patterns emerge, then building what you have seen.
              </p>
              <div className="flex flex-wrap gap-2">
                {['INFJ', 'Type 5w4', 'Strategic', 'The Seer', 'Acts → Words'].map((t) => (
                  <span key={t} className="px-3 py-1 rounded-full bg-white/10 border border-white/20 text-xs text-white/90">
                    {t}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section className="bg-white border-t border-faint">
          <div className="max-w-3xl mx-auto px-6 py-20 text-center">
            <h2 className="font-serif text-4xl leading-tight mb-4 text-balance">Ready to go deep?</h2>
            <p className="text-lg text-mist mb-8 text-balance">
              Join people who want to know themselves, actually.
            </p>
            <Link href="/signup">
              <Button variant="dark" size="lg">Start your deepdown</Button>
            </Link>
          </div>
        </section>
      </main>

      <footer className="border-t border-faint bg-white">
        <div className="max-w-6xl mx-auto px-6 py-8 flex items-center justify-between text-sm text-mist">
          <div className="flex items-center gap-2">
            <Logo size={16} className="text-mist" />
            <span>deepdown</span>
          </div>
          <span>© 2026 deepdown.io</span>
        </div>
      </footer>
    </div>
  );
}

const FRAMEWORK_CARDS = [
  { name: 'Ikigai', description: 'Your reason for being — where love, skill, purpose, and livelihood meet.' },
  { name: 'The Nine', description: 'Your core motivation — the unconscious why underneath what you do.' },
  { name: 'Archetype', description: 'Your cognitive style — how you take in the world and make decisions.' },
  { name: 'Strengths', description: 'Your top talents — the things you do naturally well.' },
  { name: 'Frequencies', description: 'How you transmit — the way you move and influence people.' },
  { name: 'Love Language', description: 'How you love — and how you need to be loved in return.' },
];
