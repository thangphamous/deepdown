import { cn } from '@/lib/utils';

export function ProgressBar({ value, max = 100, className }: { value: number; max?: number; className?: string }) {
  const pct = Math.min(100, Math.max(0, Math.round((value / max) * 100)));
  return (
    <div className={cn('h-1 w-full rounded-full bg-faint overflow-hidden', className)}>
      <div
        className="h-full bg-current transition-all duration-500 ease-out"
        style={{ width: `${pct}%` }}
      />
    </div>
  );
}
