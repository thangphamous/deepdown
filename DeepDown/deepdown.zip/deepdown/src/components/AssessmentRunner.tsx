'use client';

import { useState, useTransition, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import type { Framework, Answer } from '@/lib/frameworks/types';
import { saveResponse, completeAssessment } from '@/app/actions/assessments';
import { QuestionRenderer } from './QuestionRenderer';
import { ProgressBar } from './ProgressBar';
import { Button } from './Button';
import { Logo } from './Logo';

interface AssessmentRunnerProps {
  framework: Framework;
  assessmentId: string;
  initialResponses: Record<string, Answer>;
}

export function AssessmentRunner({ framework, assessmentId, initialResponses }: AssessmentRunnerProps) {
  const router = useRouter();
  const [responses, setResponses] = useState<Record<string, Answer>>(initialResponses);
  const [currentIdx, setCurrentIdx] = useState(() => {
    // Resume at first unanswered
    const firstUnanswered = framework.questions.findIndex((q) => !initialResponses[q.id]);
    return firstUnanswered === -1 ? 0 : firstUnanswered;
  });
  const [isPending, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);

  const question = framework.questions[currentIdx];
  const answer = responses[question.id];
  const isLast = currentIdx === framework.questions.length - 1;

  // Determine if answer is valid for moving forward
  const hasAnswer = (() => {
    if (!answer) {
      // Dual-slider auto-initializes so allow proceeding
      if (question.format === 'dual_slider' || question.format === 'ranking' || question.format === 'dual_ranking') {
        return true;
      }
      return false;
    }
    return true;
  })();

  const handleAnswer = (ans: Answer) => {
    setResponses((r) => ({ ...r, [question.id]: ans }));
    // Persist in background
    startTransition(async () => {
      try {
        await saveResponse(assessmentId, question.id, ans);
      } catch (e: any) {
        setError(e?.message || 'Failed to save');
      }
    });
  };

  // Ensure ranking/slider defaults are persisted on first view
  useEffect(() => {
    if (!responses[question.id]) {
      if (question.format === 'dual_slider') {
        handleAnswer({ axisA: 50, axisB: 50 });
      } else if (question.format === 'ranking') {
        handleAnswer({ order: question.options.map((o) => o.id) });
      } else if (question.format === 'dual_ranking') {
        handleAnswer({
          give: question.options.map((o) => o.id),
          receive: question.options.map((o) => o.id),
        });
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentIdx]);

  const goNext = () => {
    if (isLast) {
      startTransition(async () => {
        try {
          await completeAssessment(assessmentId);
          router.push(`/app/assessment/${framework.id}/complete`);
        } catch (e: any) {
          setError(e?.message || 'Failed to complete');
        }
      });
    } else {
      setCurrentIdx((i) => i + 1);
    }
  };

  const goPrev = () => setCurrentIdx((i) => Math.max(0, i - 1));

  return (
    <div className="min-h-screen bg-surface">
      <header className="border-b border-faint bg-white">
        <div className="max-w-3xl mx-auto px-6 h-14 flex items-center justify-between">
          <Link href="/app" className="text-ink">
            <Logo size={20} />
          </Link>
          <div className="flex-1 mx-8">
            <ProgressBar value={currentIdx + 1} max={framework.questions.length} />
          </div>
          <span className="text-xs text-mist tabular-nums">
            {currentIdx + 1} / {framework.questions.length}
          </span>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-6 py-12 sm:py-16">
        <div className="mb-8">
          <p className="text-xs uppercase tracking-wider text-current font-medium mb-2">
            {framework.name}
          </p>
          <p className="text-sm text-mist">{framework.tagline}</p>
        </div>

        <div className="animate-fade-in" key={question.id}>
          <QuestionRenderer question={question} value={answer} onChange={handleAnswer} />
        </div>

        {error && (
          <div className="mt-6 p-3 rounded-md bg-red-50 text-red-900 text-sm border border-red-200">
            {error}
          </div>
        )}

        <div className="mt-12 flex items-center justify-between">
          <Button variant="ghost" onClick={goPrev} disabled={currentIdx === 0}>
            ← Back
          </Button>
          <Button onClick={goNext} disabled={!hasAnswer || isPending}>
            {isLast ? (isPending ? 'Finishing…' : 'Finish assessment') : 'Next →'}
          </Button>
        </div>
      </main>
    </div>
  );
}
