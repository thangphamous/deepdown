import { cn } from '@/lib/utils';

export function Logo({ className, size = 28 }: { className?: string; size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 28 28"
      xmlns="http://www.w3.org/2000/svg"
      className={cn('inline-block', className)}
    >
      <circle cx="14" cy="14" r="12" fill="none" stroke="currentColor" strokeWidth="1.5" opacity="0.3" />
      <circle cx="14" cy="14" r="8" fill="none" stroke="currentColor" strokeWidth="1.5" opacity="0.5" />
      <circle cx="14" cy="14" r="4" fill="currentColor" />
    </svg>
  );
}

export function Wordmark({ className }: { className?: string }) {
  return (
    <div className={cn('flex items-center gap-2.5 text-current', className)}>
      <Logo size={24} />
      <span className="text-lg font-medium tracking-tight lowercase">deepdown</span>
    </div>
  );
}
