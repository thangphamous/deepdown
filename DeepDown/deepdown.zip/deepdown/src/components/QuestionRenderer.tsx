'use client';

import { useState } from 'react';
import { cn } from '@/lib/utils';
import type {
  Question,
  Answer,
  LikertAnswer,
  ForcedChoiceAnswer,
  ScenarioAnswer,
  DualSliderAnswer,
  RankingAnswer,
  DualRankingAnswer,
} from '@/lib/frameworks/types';

interface QuestionRendererProps {
  question: Question;
  value?: Answer;
  onChange: (answer: Answer) => void;
}

export function QuestionRenderer({ question, value, onChange }: QuestionRendererProps) {
  switch (question.format) {
    case 'likert':
      return <LikertRenderer question={question} value={value as LikertAnswer | undefined} onChange={onChange} />;
    case 'forced_choice':
      return <ForcedChoiceRenderer question={question} value={value as ForcedChoiceAnswer | undefined} onChange={onChange} />;
    case 'scenario':
      return <ScenarioRenderer question={question} value={value as ScenarioAnswer | undefined} onChange={onChange} />;
    case 'dual_slider':
      return <DualSliderRenderer question={question} value={value as DualSliderAnswer | undefined} onChange={onChange} />;
    case 'ranking':
      return <RankingRenderer question={question} value={value as RankingAnswer | undefined} onChange={onChange} />;
    case 'dual_ranking':
      return <DualRankingRenderer question={question} value={value as DualRankingAnswer | undefined} onChange={onChange} />;
  }
}

// ---- Likert ----
function LikertRenderer({
  question,
  value,
  onChange,
}: {
  question: Extract<Question, { format: 'likert' }>;
  value?: LikertAnswer;
  onChange: (a: LikertAnswer) => void;
}) {
  const labels = ['Strongly disagree', 'Disagree', 'Neutral', 'Agree', 'Strongly agree'];
  return (
    <div>
      <p className="font-serif text-2xl leading-snug text-ink mb-10 text-balance">{question.prompt}</p>
      <div className="flex items-center justify-between gap-2">
        {([1, 2, 3, 4, 5] as const).map((n, i) => {
          const selected = value?.value === n;
          return (
            <button
              key={n}
              onClick={() => onChange({ value: n })}
              className={cn(
                'flex flex-col items-center gap-2 flex-1 group',
                'focus-visible:outline-none',
              )}
            >
              <span
                className={cn(
                  'h-12 w-12 rounded-full border transition-all',
                  selected
                    ? 'bg-current border-current scale-110'
                    : 'bg-white border-faint group-hover:border-mist',
                )}
              />
              <span className={cn('text-xs text-center', selected ? 'text-ink font-medium' : 'text-mist')}>
                {labels[i]}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

// ---- Forced choice ----
function ForcedChoiceRenderer({
  question,
  value,
  onChange,
}: {
  question: Extract<Question, { format: 'forced_choice' }>;
  value?: ForcedChoiceAnswer;
  onChange: (a: ForcedChoiceAnswer) => void;
}) {
  return (
    <div>
      <p className="text-sm text-mist mb-4">{question.prompt}</p>
      <div className="space-y-3">
        {question.options.map((opt, idx) => {
          const selected = value?.value === idx;
          return (
            <button
              key={idx}
              onClick={() => onChange({ value: idx as 0 | 1 })}
              className={cn(
                'w-full text-left p-5 rounded-lg border transition-all',
                'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-current',
                selected
                  ? 'bg-abyss text-white border-abyss'
                  : 'bg-white text-ink border-faint hover:border-mist',
              )}
            >
              <span className="font-serif text-lg leading-snug">{opt.text}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

// ---- Scenario ----
function ScenarioRenderer({
  question,
  value,
  onChange,
}: {
  question: Extract<Question, { format: 'scenario' }>;
  value?: ScenarioAnswer;
  onChange: (a: ScenarioAnswer) => void;
}) {
  return (
    <div>
      <p className="font-serif text-2xl leading-snug text-ink mb-6 text-balance">{question.prompt}</p>
      <div className="space-y-2">
        {question.options.map((opt, idx) => {
          const selected = value?.value === idx;
          return (
            <button
              key={idx}
              onClick={() => onChange({ value: idx })}
              className={cn(
                'w-full text-left p-4 rounded-md border transition-all text-sm leading-relaxed',
                'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-current',
                selected
                  ? 'bg-deep text-white border-deep'
                  : 'bg-white text-ink border-faint hover:border-mist',
              )}
            >
              {opt.text}
            </button>
          );
        })}
      </div>
    </div>
  );
}

// ---- Dual slider ----
function DualSliderRenderer({
  question,
  value,
  onChange,
}: {
  question: Extract<Question, { format: 'dual_slider' }>;
  value?: DualSliderAnswer;
  onChange: (a: DualSliderAnswer) => void;
}) {
  const current = value || { axisA: 50, axisB: 50 };

  return (
    <div>
      <p className="font-serif text-2xl leading-snug text-ink mb-8 text-balance">{question.prompt}</p>

      <div className="space-y-8">
        <div>
          <div className="flex items-baseline justify-between mb-2">
            <span className="text-sm text-mist">{question.axisA.low}</span>
            <span className="text-sm font-medium text-ink">{question.axisA.label}</span>
            <span className="text-sm text-mist">{question.axisA.high}</span>
          </div>
          <input
            type="range"
            min={0}
            max={100}
            step={1}
            value={current.axisA}
            onChange={(e) => onChange({ axisA: Number(e.target.value), axisB: current.axisB })}
            className="w-full"
          />
        </div>

        <div>
          <div className="flex items-baseline justify-between mb-2">
            <span className="text-sm text-mist">{question.axisB.low}</span>
            <span className="text-sm font-medium text-ink">{question.axisB.label}</span>
            <span className="text-sm text-mist">{question.axisB.high}</span>
          </div>
          <input
            type="range"
            min={0}
            max={100}
            step={1}
            value={current.axisB}
            onChange={(e) => onChange({ axisA: current.axisA, axisB: Number(e.target.value) })}
            className="w-full"
          />
        </div>
      </div>
    </div>
  );
}

// ---- Ranking ----
function RankingRenderer({
  question,
  value,
  onChange,
}: {
  question: Extract<Question, { format: 'ranking' }>;
  value?: RankingAnswer;
  onChange: (a: RankingAnswer) => void;
}) {
  const [order, setOrder] = useState<string[]>(
    value?.order ?? question.options.map((o) => o.id),
  );

  const move = (idx: number, dir: -1 | 1) => {
    const newOrder = [...order];
    const target = idx + dir;
    if (target < 0 || target >= newOrder.length) return;
    [newOrder[idx], newOrder[target]] = [newOrder[target], newOrder[idx]];
    setOrder(newOrder);
    onChange({ order: newOrder });
  };

  return (
    <div>
      <p className="font-serif text-2xl leading-snug text-ink mb-6 text-balance">{question.prompt}</p>
      <div className="space-y-2">
        {order.map((optId, idx) => {
          const opt = question.options.find((o) => o.id === optId)!;
          return (
            <div
              key={optId}
              className="flex items-center gap-3 p-3 bg-white rounded-md border border-faint"
            >
              <span className="flex-shrink-0 h-6 w-6 rounded-full bg-abyss text-white text-xs font-medium flex items-center justify-center">
                {idx + 1}
              </span>
              <span className="flex-1 text-sm leading-snug text-ink">{opt.text}</span>
              <div className="flex gap-1">
                <button
                  onClick={() => move(idx, -1)}
                  disabled={idx === 0}
                  className="h-7 w-7 rounded flex items-center justify-center text-mist hover:text-ink disabled:opacity-30 disabled:cursor-not-allowed"
                  aria-label="Move up"
                >
                  ↑
                </button>
                <button
                  onClick={() => move(idx, 1)}
                  disabled={idx === order.length - 1}
                  className="h-7 w-7 rounded flex items-center justify-center text-mist hover:text-ink disabled:opacity-30 disabled:cursor-not-allowed"
                  aria-label="Move down"
                >
                  ↓
                </button>
              </div>
            </div>
          );
        })}
      </div>
      <p className="text-xs text-mist mt-3">Top = most like you · Bottom = least like you</p>
    </div>
  );
}

// ---- Dual ranking (give + receive) ----
function DualRankingRenderer({
  question,
  value,
  onChange,
}: {
  question: Extract<Question, { format: 'dual_ranking' }>;
  value?: DualRankingAnswer;
  onChange: (a: DualRankingAnswer) => void;
}) {
  const [give, setGive] = useState<string[]>(
    value?.give ?? question.options.map((o) => o.id),
  );
  const [receive, setReceive] = useState<string[]>(
    value?.receive ?? question.options.map((o) => o.id),
  );

  const moveList = (
    list: string[],
    setList: (v: string[]) => void,
    idx: number,
    dir: -1 | 1,
    which: 'give' | 'receive',
  ) => {
    const newList = [...list];
    const target = idx + dir;
    if (target < 0 || target >= newList.length) return;
    [newList[idx], newList[target]] = [newList[target], newList[idx]];
    setList(newList);
    onChange({
      give: which === 'give' ? newList : give,
      receive: which === 'receive' ? newList : receive,
    });
  };

  return (
    <div className="space-y-8">
      <div>
        <h3 className="font-serif text-xl text-ink mb-4 text-balance">{question.prompts.give}</h3>
        <RankingList
          order={give}
          options={question.options}
          onMove={(idx, dir) => moveList(give, setGive, idx, dir, 'give')}
        />
      </div>

      <div className="border-t border-faint pt-8">
        <h3 className="font-serif text-xl text-ink mb-4 text-balance">{question.prompts.receive}</h3>
        <RankingList
          order={receive}
          options={question.options}
          onMove={(idx, dir) => moveList(receive, setReceive, idx, dir, 'receive')}
        />
      </div>
    </div>
  );
}

function RankingList({
  order,
  options,
  onMove,
}: {
  order: string[];
  options: Array<{ id: string; text: string }>;
  onMove: (idx: number, dir: -1 | 1) => void;
}) {
  return (
    <div className="space-y-2">
      {order.map((optId, idx) => {
        const opt = options.find((o) => o.id === optId)!;
        return (
          <div
            key={optId}
            className="flex items-center gap-3 p-3 bg-white rounded-md border border-faint"
          >
            <span className="flex-shrink-0 h-6 w-6 rounded-full bg-abyss text-white text-xs font-medium flex items-center justify-center">
              {idx + 1}
            </span>
            <span className="flex-1 text-sm leading-snug text-ink">{opt.text}</span>
            <div className="flex gap-1">
              <button
                onClick={() => onMove(idx, -1)}
                disabled={idx === 0}
                className="h-7 w-7 rounded flex items-center justify-center text-mist hover:text-ink disabled:opacity-30 disabled:cursor-not-allowed"
                aria-label="Move up"
              >
                ↑
              </button>
              <button
                onClick={() => onMove(idx, 1)}
                disabled={idx === order.length - 1}
                className="h-7 w-7 rounded flex items-center justify-center text-mist hover:text-ink disabled:opacity-30 disabled:cursor-not-allowed"
                aria-label="Move down"
              >
                ↓
              </button>
            </div>
          </div>
        );
      })}
    </div>
  );
}
