# deepdown.io

A platform for deep self-knowledge. Six personality frameworks synthesized into a single archetype.

> *How deep will you go?*

---

## What's in this codebase

This is a v1 implementation of deepdown.io — fully working end-to-end. Users can sign up, take all six assessments, see their synthesized archetype, and share their profile with others.

- **Stack**: Next.js 14 (App Router), TypeScript, Tailwind CSS, Supabase (Postgres + Auth)
- **Six frameworks**: Ikigai · The Nine · Archetype · Strengths · Frequencies · Love Language
- **Real content**: 142 actual questions across the six frameworks, with real scoring logic
- **Synthesis engine**: composes a unified archetype (e.g., "The Contemplative Builder") from the six results
- **Auth**: email magic link + Google OAuth via Supabase
- **Sharing**: public share links with unique tokens
- **Schema ready for expansion**: workspaces (B2B), relationships (dating/couples), privacy controls — UI not yet built but data model supports them

---

## Quick start

### 1. Install dependencies

```bash
npm install
```

### 2. Set up Supabase

1. Create a new project at [supabase.com](https://supabase.com)
2. In the SQL editor, run the contents of `supabase/migrations/20260420000001_initial_schema.sql`
3. Get your project credentials from Settings → API

### 3. Configure environment

Copy `.env.example` to `.env.local` and fill in:

```
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key
NEXT_PUBLIC_SITE_URL=http://localhost:3000
```

### 4. Configure auth providers (Supabase dashboard)

- **Email**: enabled by default. Magic links will work out of the box.
- **Google OAuth**:
  1. Create OAuth credentials at [Google Cloud Console](https://console.cloud.google.com)
  2. Add `https://your-project.supabase.co/auth/v1/callback` as an authorized redirect URI
  3. In Supabase: Authentication → Providers → Google → add your Client ID and Secret

### 5. Run

```bash
npm run dev
```

Visit `http://localhost:3000`.

---

## Project structure

```
src/
├── app/                          # Next.js app router pages
│   ├── page.tsx                  # Landing page
│   ├── login/                    # Login page + form
│   ├── signup/                   # Signup (shares login form)
│   ├── auth/callback/            # OAuth/magic-link callback
│   ├── app/                      # Authenticated area (middleware-protected)
│   │   ├── layout.tsx            # App shell with nav
│   │   ├── page.tsx              # Dashboard
│   │   ├── profile/              # Profile page
│   │   └── assessment/           # Assessment taker
│   │       └── [frameworkId]/
│   │           ├── page.tsx      # Intro + runner
│   │           └── complete/     # Post-assessment result
│   ├── s/[token]/                # Public share view
│   ├── actions/                  # Server actions
│   ├── layout.tsx                # Root layout
│   ├── globals.css               # Global styles + Tailwind
│   └── not-found.tsx
├── components/
│   ├── AssessmentRunner.tsx      # Orchestrates the assessment flow
│   ├── QuestionRenderer.tsx      # Renders all 6 question formats
│   ├── Button.tsx
│   ├── Logo.tsx
│   └── ProgressBar.tsx
├── lib/
│   ├── frameworks/               # Assessment framework library
│   │   ├── types.ts              # Shared types
│   │   ├── archetype.ts          # MBTI-inspired (24 likert qs)
│   │   ├── nine.ts               # Enneagram-inspired (27 forced-choice)
│   │   ├── ikigai.ts             # Purpose (20 dual-slider)
│   │   ├── strengths.ts          # StrengthsFinder-inspired (6 ranking rounds)
│   │   ├── frequencies.ts        # 7 Frequencies (3 scenarios × 7 options)
│   │   ├── love_language.ts      # Love Languages (dual ranking give/receive)
│   │   ├── synthesis.ts          # Composes unified archetype from 6 results
│   │   └── index.ts              # Exports + scoring dispatcher
│   ├── supabase/                 # Supabase clients
│   │   ├── client.ts             # Browser client
│   │   ├── server.ts             # Server Component/Action client
│   │   ├── service.ts            # Service-role (for share tokens)
│   │   └── types.ts              # DB types
│   └── utils.ts
└── middleware.ts                 # Auth middleware

supabase/
└── migrations/
    └── 20260420000001_initial_schema.sql   # Full schema with RLS
```

---

## How it works

### The assessment flow

1. User lands on dashboard → picks a framework
2. Intro page shows what's ahead → clicks "Begin"
3. `startAssessment()` server action creates (or resumes) an assessment row
4. `AssessmentRunner` renders questions one at a time
5. Each answer hits `saveResponse()` → stored in `responses` table (upsert)
6. User navigates freely; progress is preserved
7. Final "Finish" calls `completeAssessment()`:
   - Loads all responses
   - Runs framework-specific scoring function
   - Updates `assessments.status = 'completed'` with result
   - Calls `synthesizeProfile()` which re-composes the user's archetype

### The synthesis engine

The magic happens in `src/lib/frameworks/synthesis.ts`:

- **Qualifier** derived from: primary Frequency + Nine type + Archetype I/E modulation
- **Role** derived from: top Strength + Ikigai dominant quadrant
- Produces: `"The [Qualifier] [Role]"` (e.g., "The Contemplative Builder")
- Plus a narrative paragraph, and tag chips

About 60 unique archetype names are possible from the combinatorics.

### Schema highlights

- `profiles.framework_results` caches all results as JSONB for fast reads
- `assessments.framework_version` lets you tune scoring without corrupting old data
- `workspaces` is polymorphic (personal/couple/team/family) — v1 creates a personal one per user
- `workspace_members.visibility_settings` is the privacy layer for B2B
- RLS is on for all user data; `shares` uses service role for public token access

---

## Extending the product

### Add a new framework
1. Create `src/lib/frameworks/new_framework.ts` (question data + scoring fn)
2. Add it to `src/lib/frameworks/index.ts` (dispatcher + order)
3. Add a row to the `frameworks` seed in the migration
4. Wire it into the synthesis engine if it should affect the archetype

### Build the LLM companion (deferred)
- Add `/app/companion/` route
- Store conversations in new `companion_conversations` + `companion_messages` tables
- Inject the user's `profile.framework_results` into the system prompt
- Use Anthropic Claude API — see [docs.claude.com](https://docs.claude.com)

### Build the couples layer (deferred)
- Schema already exists (`relationships` + `workspaces.type = 'couple'`)
- Build `/app/partners` UI to send invites
- Implement `calculateCompatibility()` using both users' framework results
- Add `/app/couple/[relationshipId]` page for compatibility reports

### Build B2B workspaces (deferred)
- Add workspace switcher to app header
- Build `/app/team/[workspaceId]` pages
- Build team admin UI (invite members, manage visibility)
- Add team-level pricing plans to `workspaces.plan`

### Add payments
- Install Stripe, wire into a `subscriptions` table
- Gate paid content in profile (extended narrative, full framework deep dives)
- Add `/app/billing` page

---

## Deployment

### Vercel (recommended)

1. Push to GitHub
2. Import the repo in Vercel
3. Add all `.env.local` variables to Vercel's env settings
4. Update `NEXT_PUBLIC_SITE_URL` to your deployed URL
5. In Google Cloud Console, add your deployed URL to authorized redirect URIs
6. In Supabase Auth URL Configuration, add your deployed URL

### DNS

Point `deepdown.io` at Vercel per their DNS docs. Vercel handles SSL automatically.

---

## Notes for your cloud bot / next builder

- **Frameworks are data-driven.** Tune questions and scoring without touching UI. The `QuestionRenderer` handles all six formats.
- **Scoring is versioned.** `frameworks.version` + `assessments.framework_version` means v2 scoring won't corrupt v1 results.
- **All user data is behind RLS.** Shares use service role + token. If you add new tables, follow the same pattern.
- **Synthesis narratives are currently static templates.** Easy first upgrade: replace `generateNarrative()` with a Claude API call for richer, personalized copy.
- **No payments yet.** Free-forever for v1. Gate features in the UI when you add billing (free vs paid toggle in profile, etc.).

---

## License

Proprietary. © 2026 deepdown.io
